@extends('define-degree.layout')
@section('content')
@if (session('admin_role')[14] == 1)
    <section>



        <div class="container mt-4  ">
            @if ($errors->any())
                <div class="alert alert-danger">
                    <ul>
                        @foreach ($errors->all() as $error)
                            <li>{{ $error }}</li>
                        @endforeach
                    </ul>
                </div>
            @endif


        </div>
        <div class="col-md-12 bg-danger py-1 mb-2">
            <div class="pt-1 ">
                <h2 class="text-center text-light">تنبيهات العلاوات المستحقة</h2>
               


            </div>
        </div>

        {{-- <div class="row me-1">
            <div class="col-md-4 offset-md-3">
                <form method="POST" action="{{ route('bonusreport') }}">
                    @method('POST')
                    @csrf
                    <div class="input-group">
                        <label for="" class="m-2">التاريخ من </label>
                        <input type="date" class="form-control" value="{{ isset($from) ? $from : date('Y-m-d') }}"
                            name="from">
                        <label for="" class="m-2">التاريخ الى </label>
                        <input type="date" class="form-control" value="{{ isset($to) ? $to : date('Y-m-d') }}"
                            name="to">
                        <button type="submit" class="btn btn-warning me-1" name="search">فلترة التقرير</button>
                    </div>
                </form>
            </div>
        </div> --}}
        <div class="container-fluid mt-3 ">

            @if ($msg = Session::get('success'))
                <div class="alert alert-success mt-2" role="alert">
                    {{ $msg }}
                    <!-- Close button for the alert -->
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
            @endif
            <table id="dtBasicExample" class="table table-striped table-bordered table-sm" cellspacing="0" width="100%">
                <thead class="table-dark">
                    <tr>
                        <th class="th-sm">رقم الموظف</th>
                        <th class="th-sm">اسم الموظف</th>
                       
                     
                        <th class="th-sm">مكان العمل</th>
                     
                        <th class="th-sm">الدرجة</th>
                        <th class="th-sm">المرحلة</th>
                        <th class="th-sm">الراتب الحالي</th>
                   
                        <th class="th-sm">نوع القيد</th>
                        <th class="th-sm">اخر علاوة</th>
                     
                        <th class="th-sm">الدرجة الجديدة</th>
                        <th class="th-sm">المرحلة الجديدة</th>
                        <th class="th-sm">الراتب الجديد</th>
                        <th class="th-sm">تاريخ العلاوة الجديدة</th>
                  
                        <th class="th-sm"></th>
                        <th class="th-sm"></th>
                        <th class="th-sm"></th>
                        <th class="th-sm"></th>
                        <th class="th-sm"></th>
                        <th class="th-sm"></th>
                    </tr>
                </thead>
              
                    <tbody>
                        @foreach ($employees as $employee)
                            <tr>
                                <td>
                                    {{ $employee->emp_number }}
                                </td>
                                <td>
                                    {{ $employee->emp_name }}
                                </td>


                            

                                <td>
                                    {{ $employee->department }}
                                </td>

                               

                                <td>
                                    {{ $employee->degree }}
                                </td>

                                <td>
                                    {{ $employee->stage }}
                                </td>
                                <td>
                                    {{ $employee->salary }}
                                </td>
                               
                                <td>
                                    {{ $employee->emp_type }}
                                </td>
                                <td class="text-danger " style="font-weight: bold">
                                    {{ $employee->last_bonus }}
                                </td>
                               

                                <td>
                                    {{ $employee->new_degree }}
                                </td>

                                <td>
                                    {{ $employee->new_stage }}
                                </td>

                                <td>
                                    {{ $employee->new_salary }}
                                </td>

                                <td class="text-danger " style="font-weight: bold">
                                    {{ $employee->new_bonus }}
                                </td>
                            


{{-- 
                                <td>
                                    <form action="{{ route('employee.destroy', $employee->id) }}" method="post">
                                        @method('delete')
                                        @csrf

                                        <input class="form-control btn btn-danger btn-lg" type="submit" value="حذف"
                                            id="deleteform" onclick="return confirmDelete();"
                                            style="width: 90px ;height: 62px;">

                                    </form>
                                </td> --}}
                                <td>
                                    <a class= "btn btn-primary"
                                        href="{{ route('viewThanks', ['id' => $employee->id, 'emp_name' => $employee->emp_name]) }}"  style="width: 90px ;height: 62px;">عرض
                                        التشكرات</a>
                                </td>
                                <td>
                                    <a class= "btn btn-success"
                                        href="{{ route('viewPelanty', ['id' => $employee->id, 'emp_name' => $employee->emp_name]) }}"  style="width: 90px ;height: 62px;">عرض
                                        العقوبات</a>
                                </td>
                                <td>
                                    <a class= "btn btn-primary"
                                        href="{{ route('viewvac', ['id' => $employee->id, 'emp_name' => $employee->emp_name]) }}"  style="width: 90px ;height: 62px;">عرض
                                        الاجازات</a>
                                </td>
                                <td>
                                    <a class= "btn btn-success"
                                        href="{{ route('viewAbsence', ['id' => $employee->id, 'emp_name' => $employee->emp_name]) }}"  style="width: 90px ;height: 62px;">عرض
                                        الغيابات</a>
                                </td>
                                <td>
                                    <a class= "btn btn-danger"
                                        href="{{ route('gbonuscreate', ['emp_id' => $employee->id, 'emp_name' => $employee->emp_name]) }}"  style="width: 90px ;height: 62px;">
                                        اصدار علاوة</a>
                                </td>
                                <td>
                                    <a class= "btn btn-primary"
                                        href="{{ route('viewgbonus', ['emp_id' => $employee->id, 'emp_name' => $employee->emp_name]) }}"  style="width: 90px ;height: 62px;">
                                        عرض العلاوات </a>
                                </td>
                            </tr>
                        @endforeach





                    </tbody>
              

                <tfoot>




                </tfoot>
            </table>
          
                {{-- {{ $employees->links('pagination::bootstrap-5') }} --}}
         



        </div>


        <div>
        </div>


    </section>
    @else
    @php
        header('Location: ' . URL::to('/home'));
        exit();
    @endphp

@endif
@endsection
