@extends('define-degree.layout')
@section('content')
@if (session('admin_role')[4] == 1)
    <section>



        <div class="container mt-4  ">
            @if ($errors->any())
                <div class="alert alert-danger">
                    <ul>
                        @foreach ($errors->all() as $error)
                            <li>{{ $error }}</li>
                        @endforeach
                    </ul>
                </div>
            @endif
            <div class="card shadow">
                <div class="card-header">
                    <h3>تحديث فترة التنبيه</h3>
                </div>
                <div class="card-body">
                    <form class="row g-3" method="POST" id="insertform" action="{{ route('alert.store') }}">
                        @csrf
                        @method('POST')
                   
                        <div class="col-md-6">
                            <label for="inputPassword4" class="form-label">فترة التنبيه (يوم)*</label>
                            <input type="text" class="form-control" name="alertdays" id="alertdays">
                        </div>

                        <div class="col-12">
                            <button class="btn btn-primary" type="submit">
                                حفظ
                            </button>
                        </div>

                    </form>
                </div>
            </div>

        </div>
        <div class="container mt-5 ">

          @if ($msg = Session::get('success'))
          <div class="alert alert-success mt-2" role="alert">
              {{ $msg }}
              <!-- Close button for the alert -->
              <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
          </div>
          @endif



          <div class="row justify-content-center">
              <div class="table-responsive table-scroll" data-mdb-perfect-scrollbar="true" style="position: relative;">
                  <table class="table table-striped mb-0 table-bordered">
                      <thead class="table-dark">
                          <tr>
                         
                              <th scope="col">فترة التنبيه (يوم)</th>
                         
                 

                        
                             
                            
                             

                          </tr>
                      </thead>
                      <tbody>
                        @isset($alerts->alertdays)
                            
                     
                          {{-- @foreach ($alerts as $alert) --}}
                          <tr>
                              <td>
                                 {{$alerts->alertdays}}
                              </td>
                              {{-- <td>
                                 {{$degree->bonus}}
                              </td> --}}
                            
                            
                            
                                  {{-- <a class="btn btn-primary" href="{{route('def-degree.edit',['def_degree'=>$degree->id])}}">تعديل</a> --}}
                              {{-- <td>
                                  <form action="{{route('education.destroy', $alerts->id)}}" method="post">
                                      @method('delete')
                                      @csrf
                                     
                                      <input class="form-control btn btn-danger " type="submit" value="حذف" id="deleteform" onclick="return confirmDelete();">
                                      
                                  </form>
                              </td> --}}
                          </tr>
                       @endisset
                         




                      </tbody>
                      
                  </table>
                  
              
                  
                
              </div>
          


              <div>
              </div>
              
    </section>
    @else
    @php
        header('Location: ' . URL::to('/home'));
        exit();
    @endphp

@endif
@endsection
