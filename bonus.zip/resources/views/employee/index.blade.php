@extends('define-degree.layout')
@section('content')
@if (session('admin_role')[6] == 1)

    <section>



        <div class="container mt-4  ">
            @if ($errors->any())
                <div class="alert alert-danger">
                    <ul>
                        @foreach ($errors->all() as $error)
                            <li>{{ $error }}</li>
                        @endforeach
                    </ul>
                </div>
            @endif
 
        </div>
        
         <div class="row me-1">
                     <div class="col-md-3 offset-md-3">
                         <form method="POST" action="{{route('empsearch')}}">
                           @method('POST')
                           @csrf
                             <div class="input-group">
                                 <input type="text" class="form-control" placeholder="ابحث" name="keyword">
                                 <button type="submit" class="btn btn-warning me-1  "
                                     name="search">البحث</button>
                             </div>
                         </form>
                     </div>
                 </div>
        <div class="container-fluid mt-3 ">

          @if ($msg = Session::get('success'))
          <div class="alert alert-success mt-2" role="alert">
              {{ $msg }}
              <!-- Close button for the alert -->
              <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
          </div>
          @endif
          <table id="dtBasicExample" class="table table-striped table-bordered table-sm" cellspacing="0" width="100%">
            <thead class="table-dark">
              <tr>
                <th class="th-sm" >رقم الموظف</th>
                <th class="th-sm">اسم الموظف</th>
                <th class="th-sm">العنوان الوظيفي</th>
                <th class="th-sm">التحصيل الدراسي</th>
                <th class="th-sm">مكان العمل</th>
                <th class="th-sm">تاريخ الميلاد</th>
                <th class="th-sm">الدرجة</th>
                <th class="th-sm">المرحلة</th>
                <th class="th-sm">الراتب الحالي</th>
                <th class="th-sm">تاريخ المباشرة</th>
                <th class="th-sm">نوع القيد</th>
                <th class="th-sm">اخر علاوة</th>
                <th class="th-sm">اخر ترفيع</th>
                <th class="th-sm">الدرجة الجديدة</th>
                <th class="th-sm">المرحلة الجديدة</th>
                <th class="th-sm">الراتب الجديدة</th>
                <th class="th-sm">تاريخ العلاوة الجديدة</th>
                <th class="th-sm">تاريخ الترفيع الجديد</th>
                <th class="th-sm">تاريخ التقاعد</th>
                <th class="th-sm"></th>
                <th class="th-sm"></th>
                <th class="th-sm"></th>
                <th class="th-sm"></th>
                <th class="th-sm"></th>
                <th class="th-sm"></th>
                <th class="th-sm"></th>
                <th class="th-sm"></th>
                <th class="th-sm"></th>
               
              </tr>
            </thead>
            <tbody>
                @foreach ($employees as $employee)
                <tr>
                    <td>
                       {{$employee->emp_number}}
                    </td>
                    <td>
                       {{$employee->emp_name}}
                    </td>
                  
                    <td>
                       {{$employee->jobdes}}
                    </td>
                  
                    <td>
                       {{$employee->education}}
                    </td>
                  
                    <td>
                       {{$employee->department}}
                    </td>
                  
                    <td>
                       {{$employee->birth_day}}
                    </td>
                  
                    <td>
                       {{$employee->degree}}
                    </td>
                  
                    <td>
                       {{$employee->stage}}
                    </td>
                    <td>
                       {{$employee->salary}}
                    </td>
                    <td>
                       {{$employee->start_date}}
                    </td>
                    <td>
                       {{$employee->emp_type}}
                    </td>
                    <td>
                       {{$employee->last_bonus}}
                    </td>
                    <td>
                       {{$employee->last_pro}}
                    </td>
                  
                    <td>
                       {{$employee->new_degree}}
                    </td>
                  
                    <td>
                       {{$employee->new_stage}}
                    </td>
                  
                    <td>
                       {{$employee->new_salary}}
                    </td>
                  
                    <td>
                       {{$employee->new_bonus}}
                    </td>
                    <td>
                       {{$employee->new_pro}}
                    </td>
                    <td>
                       {{$employee->retire_date}}
                    </td>
                  
                  
                   
              
                    {{-- <td>
                        <form action="{{route('employee.destroy',$employee->id)}}" method="post">
                            @method('delete')
                            @csrf
                           
                            <input class="form-control btn btn-danger btn-lg" type="submit" value="حذف" id="deleteform" onclick="return confirmDelete();" style="width: 90px ;height: 62px;">
                            
                        </form>
                    </td> --}}
                    <td>
                     <a  class= "btn btn-danger" href="{{route('employee.edit',$employee->id)}}">تعديل معلومات</a>
                    </td>
                    <td>
                     <a  class= "btn btn-primary" href="{{route('viewThanks',['id'=>$employee->id,'emp_name'=>$employee->emp_name])}}">عرض التشكرات</a>
                    </td>
                    <td>
                     <a  class= "btn btn-success" href="{{route('viewPelanty',['id'=>$employee->id,'emp_name'=>$employee->emp_name])}}">عرض العقوبات</a>
                    </td>
                    <td>
                     <a  class= "btn btn-primary" href="{{route('viewvac',['id'=>$employee->id,'emp_name'=>$employee->emp_name])}}">عرض الاجازات</a>
                    </td>
                    <td>
                     <a  class= "btn btn-success" href="{{route('viewAbsence',['id'=>$employee->id,'emp_name'=>$employee->emp_name])}}">عرض الغيابات</a>
                    </td>
                    <td>
                     <a class= "btn btn-danger"
                         href="{{ route('gbonuscreate', ['emp_id' => $employee->id, 'emp_name' => $employee->emp_name]) }}"  style="width: 90px ;height: 62px;">
                         اصدار علاوة</a>
                 </td>
                 <td>
                     <a class= "btn btn-primary"
                         href="{{ route('viewgbonus', ['emp_id' => $employee->id, 'emp_name' => $employee->emp_name]) }}"  style="width: 90px ;height: 62px;">
                         عرض العلاوات </a>
                 </td>
                 <td>
                  <a class= "btn btn-danger"
                      href="{{ route('gprocreate', ['emp_id' => $employee->id, 'emp_name' => $employee->emp_name]) }}"  style="width: 90px ;height: 62px;">
                      اصدار ترفيع</a>
              </td>
              <td>
                  <a class= "btn btn-primary"
                      href="{{ route('viewgpro', ['emp_id' => $employee->id, 'emp_name' => $employee->emp_name]) }}"  style="width: 90px ;height: 62px;">
                      عرض الترفيعات </a>
              </td>
                </tr>

                @endforeach
               




            </tbody>
           
            <tfoot>
               
              
          
             
            </tfoot>
         </table>
         {{$employees->links('pagination::bootstrap-5')}}


{{-- 
          <div class="row justify-content-center">
              <div class="table-responsive table-scroll" data-mdb-perfect-scrollbar="true" style="position: relative;">
                  <table class="table table-striped mb-0 table-bordered">
                      <thead class="table-dark">
                          <tr>
                         
                              <th scope="col">رقم الموظف</th>
                              <th scope="col">اسم الموظف</th>
                              <th scope="col">العنوان الوظيفي</th>
                              <th scope="col">التحصيل الدراسي</th>
                              <th scope="col">مكان العمل</th>
                              <th scope="col">تاريخ الميلاد</th>
                              <th scope="col">الدرجة</th>
                              <th scope="col">المرحلة</th>
                              <th scope="col">الراتب الحالي</th>
                              <th scope="col">تاريخ المباشرة</th>
                              <th scope="col">نوع القيد</th>
                              <th scope="col">اخر علاوة</th>
                              <th scope="col">اخر ترفيع</th>
                              <th scope="col">الدرجة الجديدة</th>
                              <th scope="col">المرحلة الجديدة</th>
                              <th scope="col">الراتب الجديدة</th>
                              <th scope="col">تاريخ العلاوة الجديدة</th>
                              <th scope="col">تاريخ الترفيع الجديد</th>
                              <th scope="col">تاريخ التقاعد</th>
                 

                              <th scope="col"></th>
                              
                            
                             

                          </tr>
                      </thead>
                      <tbody>
                          @foreach ($employees as $employee)
                          <tr>
                              <td>
                                 {{$employee->emp_number}}
                              </td>
                              <td>
                                 {{$employee->emp_name}}
                              </td>
                            
                              <td>
                                 {{$employee->jobdes}}
                              </td>
                            
                              <td>
                                 {{$employee->education}}
                              </td>
                            
                              <td>
                                 {{$employee->department}}
                              </td>
                            
                              <td>
                                 {{$employee->birth_day}}
                              </td>
                            
                              <td>
                                 {{$employee->degree}}
                              </td>
                            
                              <td>
                                 {{$employee->stage}}
                              </td>
                              <td>
                                 {{$employee->salary}}
                              </td>
                              <td>
                                 {{$employee->start_date}}
                              </td>
                              <td>
                                 {{$employee->emp_type}}
                              </td>
                              <td>
                                 {{$employee->last_bonus}}
                              </td>
                              <td>
                                 {{$employee->last_pro}}
                              </td>
                            
                              <td>
                                 {{$employee->new_degree}}
                              </td>
                            
                              <td>
                                 {{$employee->new_stage}}
                              </td>
                            
                              <td>
                                 {{$employee->new_salary}}
                              </td>
                            
                              <td>
                                 {{$employee->new_bonus}}
                              </td>
                              <td>
                                 {{$employee->new_pro}}
                              </td>
                              <td>
                                 {{$employee->retire_date}}
                              </td>
                            
                            
                             
                        
                              <td>
                                  <form action="{{route('employee.destroy',$employee->id)}}" method="post">
                                      @method('delete')
                                      @csrf
                                     
                                      <input class="form-control btn btn-danger " type="submit" value="حذف" id="deleteform" onclick="return confirmDelete();">
                                      
                                  </form>
                              </td>
                          </tr>
                          @endforeach
                         




                      </tbody>
                      
                  </table>
                   --}}
              
                  
                
              </div>
              {{-- @isset($name)
                  @empty(!$name)
                      {{ $name }}
                  @endempty
              @endisset --}}


              <div>
              </div>
              {{-- <div class="mt-2">
                  {{$emps->links('pagination::bootstrap-5')}}
              </div> --}}
               
    </section>
    @else
    @php
        header('Location: ' . URL::to('/home'));
        exit();
    @endphp

@endif
@endsection
