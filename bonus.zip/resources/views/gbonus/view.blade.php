
@extends('define-degree.layout')
@section('content')
    <section>



        <div class="container mt-4  ">
            @if ($errors->any())
                <div class="alert alert-danger">
                    <ul>
                        @foreach ($errors->all() as $error)
                            <li>{{ $error }}</li>
                        @endforeach
                    </ul>
                </div>
            @endif
 

        </div>
        <div class="container mt-5 ">

          @if ($msg = Session::get('success'))
          <div class="alert alert-success mt-2" role="alert">
              {{ $msg }}
              <!-- Close button for the alert -->
              <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
          </div>
          @endif
          <div class="row justify-content-between mb-1    "
          style="  margin-right: 1px; margin-left: 1px">
          <div class="col-md-12 bg-dark">
              <div class="pt-1 ">
                  <h2 class="text-center text-warning">علاوات مصدرة</h2>
                 


              </div>
          </div>
          <div class="col-md-12 bg-dark mt-2">
              <div class="pt-1 ">
                  <h2 class="text-center text-light">{{$emp_name}}</h2>
                 


              </div>
          </div>
       
              
         
        

          <table id="dtBasicExample" class="table table-striped table-bordered table-sm" cellspacing="0" width="100%">
            <thead class="table-dark">
              <tr>
                <th class="th-sm" >تاريخ العلاوة المصدرة</th>
                <th class="th-sm">رقم الامر </th>
         
       
               
             
              </tr>
            </thead>
            <tbody>
                @foreach ($gbonuses  as $gbonus)
                <tr>
                    <td>
                       {{$gbonus->gbonus_date}}
                    </td>
                    <td>
                        {{$gbonus->gbonus_number}}
                    </td>
             
                  
                   
              
                    {{-- <td>
                        <form action="{{route('deletethanks',['thank_id'=>$thank->id,'emp_id'=>$emp_id])}}" method="post">
                            @method('delete')
                            @csrf
                           
                            <input class="form-control btn btn-danger " type="submit" value="حذف" id="deleteform" onclick="return confirmDelete();">
                            
                        </form>
                    </td> --}}
                    {{-- <td>
                     <a  class= "btn btn-primary" href="{{route('viewThanks',['id'=>$thank->id,'emp_name'=>$thank->id])}}">عرض التشكرات</a>
                    </td>
                    <td>
                     <a  class= "btn btn-success" href="">عرض العقوبات</a>
                    </td> --}}
                </tr>

                @endforeach
               




            </tbody>
           
            <tfoot>
               
              
          
             
            </tfoot>
         </table>
         
         {{$gbonuses->links('pagination::bootstrap-5')}}



              <div>
              </div>
      
               
    </section>
@endsection
