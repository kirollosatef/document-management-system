<?php

?>
@extends('define-degree.layout')
@section('content')


    <section class=" gradient-custom">
        @if (session('admin_role')[17] == 1)
        <div class="container py-5 h-100">
            @if ($errors->any())
                <div class="alert alert-danger">
                    <ul>
                        @foreach ($errors->all() as $error)
                            <li>{{ $error }}</li>
                        @endforeach
                    </ul>
                </div>
            @endif
            @if ($msg = Session::get('success'))
            <div class="alert alert-success mt-2" role="alert">
                {{ $msg }}
                <!-- Close button for the alert -->
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
            @endif
            <div class="row d-flex justify-content-center align-items-center h-100">
                <div class="col-12 col-md-8 col-lg-6 col-xl-5">
                    <div class="card bg-dark text-white" style="border-radius: 1rem;">
                        <div class="card-body p-5 text-center">

                            <div class="mb-md-5 mt-md-4 pb-5">

                                <h2 class="fw-bold mb-2 text-uppercase"> نظام ادارة العلاوات والترفيعات</h2>
                                <p class="text-white-50 mb-5">قم بادخال اسم المستخدم وكلمة المرور وحدد صلاحيات المستخدم
                                </p>

                                <form action="{{route('admin.store')}}" method="POST">
                                    @csrf
                                    @method('POST')
                                    <div class="form-outline form-white mb-4">
                                        <label class="form-label" for="typeEmailX">اسم المستخدم</label>
                                        <input type="text" id="typeEmailX" class="form-control form-control-lg"
                                            name="username" />
                                    </div>

                                    <div class="form-outline form-white mb-4">
                                        <label class="form-label" for="typePasswordX">كلمة المرور</label>
                                        <input type="password" id="typePasswordX" class="form-control form-control-lg"
                                            name="password" />
                                    </div>
                                    <div class="container mt-3">
                                        <h2>صلاحيات المستخدم</h2>

                                        <div class="form-check">
                                            <input class="form-check-input" type="checkbox" value="1" id="checkbox1"
                                                name="1">
                                            <label class="form-check-label" for="checkbox1">
                                                تعريف مواقع العمل
                                            </label>
                                        </div>

                                        <div class="form-check">
                                            <input class="form-check-input" type="checkbox" value="1" id="checkbox2"
                                                name="2">
                                            <label class="form-check-label" for="checkbox2">
                                                تعريف العناوين الوظيفية
                                            </label>
                                        </div>

                                        <div class="form-check">
                                            <input class="form-check-input" type="checkbox" value="1" id="checkbox3"
                                                name="3">
                                            <label class="form-check-label" for="checkbox3">
                                                تعريف التحصيل الدراسي
                                            </label>
                                        </div>

                                        <div class="form-check">
                                            <input class="form-check-input" type="checkbox" value="1" id="checkbox2"
                                                name="4">
                                            <label class="form-check-label" for="checkbox2">
                                                تعريف الاجازات
                                            </label>
                                        </div>

                                        <div class="form-check">
                                            <input class="form-check-input" type="checkbox" value="1" id="checkbox3"
                                                name="5">
                                            <label class="form-check-label" for="checkbox3">
                                                فترة التنبيه
                                            </label>
                                        </div>
                                        <div class="form-check">
                                            <input class="form-check-input" type="checkbox" value="1" id="checkbox1"
                                                name="6">
                                            <label class="form-check-label" for="checkbox1">
                                                فتح ملف موظف
                                            </label>
                                        </div>
                                        <div class="form-check">
                                            <input class="form-check-input" type="checkbox" value="1" id="checkbox1"
                                                name="7">
                                            <label class="form-check-label" for="checkbox1">
                                                عرض وتعديل الموظفين
                                            </label>
                                        </div>
                                        <div class="form-check">
                                            <input class="form-check-input" type="checkbox" value="1" id="checkbox1"
                                                name="8">
                                            <label class="form-check-label" for="checkbox1">
                                                التشكرات
                                            </label>
                                        </div>
                                        <div class="form-check">
                                            <input class="form-check-input" type="checkbox" value="1" id="checkbox1"
                                                name="9">
                                            <label class="form-check-label" for="checkbox1">
                                                العقوبات
                                            </label>
                                        </div>
                                        <div class="form-check">
                                            <input class="form-check-input" type="checkbox" value="1"
                                                id="checkbox1" name="10">
                                            <label class="form-check-label" for="checkbox1">
                                                الاجازات
                                            </label>
                                        </div>
                                        <div class="form-check">
                                            <input class="form-check-input" type="checkbox" value="1"
                                                id="checkbox1" name="11">
                                            <label class="form-check-label" for="checkbox1">
                                                الغيابات
                                            </label>
                                        </div>
                                        <div class="form-check">
                                            <input class="form-check-input" type="checkbox" value="1"
                                                id="checkbox1" name="12">
                                            <label class="form-check-label" for="checkbox1">
                                                تقرير العلاوات
                                            </label>
                                        </div>
                                        <div class="form-check">
                                            <input class="form-check-input" type="checkbox" value="1"
                                                id="checkbox1" name="13">
                                            <label class="form-check-label" for="checkbox1">
                                                تقرير الترفيعات
                                            </label>
                                        </div>
                                        <div class="form-check">
                                            <input class="form-check-input" type="checkbox" value="1"
                                                id="checkbox1" name="14">
                                            <label class="form-check-label" for="checkbox1">
                                                تقرير التقاعد
                                            </label>
                                        </div>
                                        <div class="form-check">
                                            <input class="form-check-input" type="checkbox" value="1"
                                                id="checkbox1" name="15">
                                            <label class="form-check-label" for="checkbox1">
                                                تنبيه العلاوة
                                            </label>
                                        </div>
                                        <div class="form-check">
                                            <input class="form-check-input" type="checkbox" value="1"
                                                id="checkbox1" name="16">
                                            <label class="form-check-label" for="checkbox1">
                                                تنبيه الترفيع
                                            </label>
                                        </div>
                                        <div class="form-check">
                                            <input class="form-check-input" type="checkbox" value="1"
                                                id="checkbox1" name="17">
                                            <label class="form-check-label" for="checkbox1">
                                                تنبيه التقاعد
                                            </label>
                                        </div>
                                        <div class="form-check">
                                            <input class="form-check-input" type="checkbox" value="1"
                                                id="checkbox1" name="18">
                                            <label class="form-check-label" for="checkbox1">
                                                اضافة مستخدمين
                                            </label>
                                        </div>




                                    </div>

                                    <!-- <p class="small mb-5 pb-lg-2"><a class="text-white-50" href="#!">Forgot password?</a></p> -->

                                    <div class="mt-2">
                                        <button class="btn btn-outline-warning btn-lg px-5" type="submit">اضافة
                                            مستخدم</button>
                                    </div>
                                </form>


                            </div>

                            <div>

                            </div>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    @else
    @php
        header('Location: ' . URL::to('/home'));
        exit();
    @endphp

@endif
@endsection
