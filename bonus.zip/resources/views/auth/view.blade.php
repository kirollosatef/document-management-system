@extends('define-degree.layout')
@section('content')
@if (session('admin_role')[17] == 1)
    <section>



        <div class="container mt-4  ">
            @if ($errors->any())
                <div class="alert alert-danger">
                    <ul>
                        @foreach ($errors->all() as $error)
                            <li>{{ $error }}</li>
                        @endforeach
                    </ul>
                </div>
            @endif
            <div class="card shadow">
                <div class="card-header bg-dark text-light text-center">
                    <h3>عرض المستخدمين</h3>
                </div>
         
            </div>

        </div>
        <div class="container mt-5 ">

          @if ($msg = Session::get('success'))
          <div class="alert alert-success mt-2" role="alert">
              {{ $msg }}
              <!-- Close button for the alert -->
              <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
          </div>
          @endif



          <div class="row justify-content-center">
              <div class="table-responsive table-scroll" data-mdb-perfect-scrollbar="true" style="position: relative;">
                  <table class="table table-striped mb-0 table-bordered">
                      <thead class="table-dark">
                          <tr>
                         
                              <th scope="col">المستخدم</th>

                              <th scope="col"></th>
                              
                            
                             

                          </tr>
                      </thead>
                      <tbody>
                          @foreach ($admins as $admin)
                          <tr>
                            @if ($admin->username!="admin")
                            <td>
                            
                                {{$admin->username}}
                             </td>
                           
                           
                              {{-- <td>
                                 {{$degree->bonus}}
                              </td> --}}
                            
                            
                             
                        
                              <td>
                                  <form action="{{route('admin.destroy',$admin->id)}}" method="post">
                                      @method('delete')
                                      @csrf
                                     
                                      <input class="form-control btn btn-danger " type="submit" value="حذف" id="deleteform" onclick="return confirmDelete();">
                                      
                                  </form>
                              </td>
                              @endif
                          </tr>
                          @endforeach
                         




                      </tbody>
                      
                  </table>
                  
              
                  
                
              </div>
              {{-- @isset($name)
                  @empty(!$name)
                      {{ $name }}
                  @endempty
              @endisset --}}


              <div>
              </div>
              {{-- <div class="mt-2">
                  {{$emps->links('pagination::bootstrap-5')}}
              </div> --}}
               
    </section>
        @else
    @php
        header('Location: ' . URL::to('/home'));
        exit();
    @endphp

@endif
@endsection
