@extends('define-degree.layout')
@section('content')

    @if (session('admin_role')[0] == 1)


        <section>



            <div class="container mt-4  ">
                @if ($errors->any())
                    <div class="alert alert-danger">
                        <ul>
                            @foreach ($errors->all() as $error)
                                <li>{{ $error }}</li>
                            @endforeach
                        </ul>
                    </div>
                @endif
                <div class="card shadow">
                    <div class="card-header">
                        <h3>تعريف مواقع العمل</h3>
                    </div>
                    <div class="card-body">
                        <form class="row g-3" method="POST" id="insertform" action="{{ route('department.store') }}">
                            @csrf
                            @method('POST')

                            <div class="col-md-6">
                                <label for="inputPassword4" class="form-label"> موقع العمل*</label>
                                <input type="text" class="form-control" name="dep_name" id="dep_name">
                            </div>

                            <div class="col-12">
                                <button class="btn btn-primary" type="submit">
                                    حفظ
                                </button>
                            </div>

                        </form>
                    </div>
                </div>

            </div>
            <div class="container mt-5 ">

                @if ($msg = Session::get('success'))
                    <div class="alert alert-success mt-2" role="alert">
                        {{ $msg }}
                        <!-- Close button for the alert -->
                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>
                @endif



                <div class="row justify-content-center">
                    <div class="table-responsive table-scroll" data-mdb-perfect-scrollbar="true"
                        style="position: relative;">
                        <table class="table table-striped mb-0 table-bordered">
                            <thead class="table-dark">
                                <tr>

                                    <th scope="col"> مواقع العمل</th>



                                    <th scope="col"></th>




                                </tr>
                            </thead>
                            <tbody>
                                @foreach ($departments as $department)
                                    <tr>
                                        <td>
                                            {{ $department->dep_name }}
                                        </td>
                                        {{-- <td>
                                 {{$degree->bonus}}
                              </td> --}}



                                        {{-- <a class="btn btn-primary" href="{{route('def-degree.edit',['def_degree'=>$degree->id])}}">تعديل</a> --}}
                                        <td>
                                            <form action="{{ route('department.destroy', $department->id) }}"
                                                method="post">
                                                @method('delete')
                                                @csrf

                                                <input class="form-control btn btn-danger " type="submit" value="حذف"
                                                    id="deleteform" onclick="return confirmDelete();">

                                            </form>
                                        </td>
                                    </tr>
                                @endforeach





                            </tbody>

                        </table>




                    </div>
                    {{-- @isset($name)
                  @empty(!$name)
                      {{ $name }}
                  @endempty
              @endisset --}}


                    <div>
                    </div>
                    {{-- <div class="mt-2">
                  {{$emps->links('pagination::bootstrap-5')}}
              </div> --}}

        </section>
    @else
        @php
            header('Location: ' . URL::to('/home'));
            exit();
        @endphp

    @endif

@endsection
