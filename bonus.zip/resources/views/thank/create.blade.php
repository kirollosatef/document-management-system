@extends('define-degree.layout')
@section('content')
@if (session('admin_role')[7] == 1)

    <section>



        <div class="container mt-4  ">
            @if ($errors->any())
                <div class="alert alert-danger">
                    <ul>
                        @foreach ($errors->all() as $error)
                            <li>{{ $error }}</li>
                        @endforeach
                    </ul>
                </div>
            @endif
            <div class="card shadow">
                <div class="card-header">
                    <h3>التشكرات</h3>
                </div>
                <div class="card-body">
                    <form class="row g-3" method="POST" id="insertform" action="{{ route('thank.store') }}">
                        @csrf
                        @method('POST')
                        <div class="col-md-4" style="margin-top:20px ;">
                            <label for="selectData" class="mb-1">اسم الموظف*</label>
                            <select class="form-control select2 custom-select-height" name="emp_id" id="emp_id">
                                <option selected disabled>اختر موظف</option>
                               @foreach ( $employees as  $employee )
                               <option value="{{$employee->id}}">{{$employee->emp_name}}</option>
                               @endforeach
                          
                            </select>
                        </div>
                        <div class="col-md-4">
                            <label for="inputPassword4" class="form-label"> تاريخ الكتاب*</label>
                            <input type="date" class="form-control" name="thanks_date" id="thanks_date" value="{{date('Y-m-d')}}">
                        </div>
                        <div class="col-md-4" style="margin-top:20px ;">
                            <label for="selectData" class="mb-1">نوع التشكر*</label>
                            <select class="form-control select2 custom-select-height" name="thanks_type" id="thanks_type">
                                <option value="كتاب شكر">كتاب شكر</option>
                                <option value="قدم">قدم</option>
                           
                             
                            </select>
                        </div>
                        <div class="col-md-4">
                            <label for="inputPassword4" class="form-label"> رقم الامر*</label>
                            <input type="text" class="form-control" name="thanks_number" id="thanks_number">
                        </div>
                        <div class="col-md-4">
                            <label for="inputPassword4" class="form-label"> قدم (يوم)*</label>
                            <input type="text" class="form-control" name="days_count" id="days_count" value="30">
                        </div>
                   
                
                      
                  
                        <div class="col-md-4">
                            <label for="inputPassword4" class="form-label">الملاحضات </label>
                            <input type="text" class="form-control" name="notes" id="notes" value="">
                        </div>
                     
                      
                     
                    

                        <div class="col-12">
                            <button class="btn btn-primary" type="submit">
                                حفظ
                            </button>
                        </div>

                    </form>
                </div>
            </div>

        </div>
        <div class="container mt-5 ">

          @if ($msg = Session::get('success'))
          <div class="alert alert-success mt-2" role="alert">
              {{ $msg }}
              <!-- Close button for the alert -->
              <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
          </div>
          @endif


               
    </section>
    @else
    @php
        header('Location: ' . URL::to('/home'));
        exit();
    @endphp

@endif
@endsection
