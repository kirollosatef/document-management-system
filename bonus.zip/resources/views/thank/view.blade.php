
@extends('define-degree.layout')
@section('content')
{{-- @if (session('admin_role')[7] == 1) --}}
    <section>



        <div class="container mt-4  ">
            @if ($errors->any())
                <div class="alert alert-danger">
                    <ul>
                        @foreach ($errors->all() as $error)
                            <li>{{ $error }}</li>
                        @endforeach
                    </ul>
                </div>
            @endif
 

        </div>
        <div class="container mt-5 ">

          @if ($msg = Session::get('success'))
          <div class="alert alert-success mt-2" role="alert">
              {{ $msg }}
              <!-- Close button for the alert -->
              <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
          </div>
          @endif
          <div class="row justify-content-between mb-1    "
          style="  margin-right: 1px; margin-left: 1px">
          <div class="col-md-12 bg-dark">
              <div class="pt-1 ">
                  <h2 class="text-center text-warning">التشكرات</h2>
                 


              </div>
          </div>
          <div class="col-md-12 bg-dark mt-2">
              <div class="pt-1 ">
                  <h2 class="text-center text-light">{{$emp_name}}</h2>
                 


              </div>
          </div>
       
              
         
        

          <table id="dtBasicExample" class="table table-striped table-bordered table-sm" cellspacing="0" width="100%">
            <thead class="table-dark">
              <tr>
                <th class="th-sm" >تاريخ الكتاب</th>
                <th class="th-sm">نوع التشكر</th>
                <th class="th-sm">رقم الامر</th>
                <th class="th-sm">القدم (يوم)</th>
                <th class="th-sm">الملاحضات</th>
       
                <th class="th-sm"></th>
             
              </tr>
            </thead>
            <tbody>
                @foreach ($thanks  as $thank)
                <tr>
                    <td>
                       {{$thank->thanks_date}}
                    </td>
                    <td>
                       {{$thank->thanks_type}}
                    </td>
                    <td>
                       {{$thank->thanks_number}}
                    </td>
                    <td>
                       {{$thank->days_count}}
                    </td>
                    <td>
                       {{$thank->notes}}
                    </td>
                 
                  
                   
              
                    <td>
                        <form action="{{route('deletethanks',['thank_id'=>$thank->id,'emp_id'=>$emp_id])}}" method="post">
                            @method('delete')
                            @csrf
                           
                            <input class="form-control btn btn-danger " type="submit" value="حذف" id="deleteform" onclick="return confirmDelete();">
                            
                        </form>
                    </td>
                    {{-- <td>
                     <a  class= "btn btn-primary" href="{{route('viewThanks',['id'=>$thank->id,'emp_name'=>$thank->id])}}">عرض التشكرات</a>
                    </td>
                    <td>
                     <a  class= "btn btn-success" href="">عرض العقوبات</a>
                    </td> --}}
                </tr>

                @endforeach
               




            </tbody>
           
            <tfoot>
               
              
          
             
            </tfoot>
         </table>
         
         {{$thanks->links('pagination::bootstrap-5')}}



              <div>
              </div>
      
               
    </section>
    {{-- @else
    @php
        header('Location: ' . URL::to('/home'));
        exit();
    @endphp

@endif --}}
@endsection
