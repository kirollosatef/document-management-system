@extends('define-degree.layout')
@section('content')
@if (session('admin_role')[10] == 1)
    <section>



        <div class="container mt-4  ">
            @if ($errors->any())
                <div class="alert alert-danger">
                    <ul>
                        @foreach ($errors->all() as $error)
                            <li>{{ $error }}</li>
                        @endforeach
                    </ul>
                </div>
            @endif
            <div class="card shadow">
                <div class="card-header">
                    <h3>الغيابات</h3>
                </div>
                <div class="card-body">
                    <form class="row g-3" method="POST" id="insertform" action="{{ route('absence.store') }}">
                        @csrf
                        @method('POST')
                        <div class="col-md-4" style="margin-top:20px ;">
                            <label for="selectData" class="mb-1">اسم الموظف*</label>
                            <select class="form-control select2 custom-select-height" name="emp_id" id="emp_id">
                                <option selected disabled>اختر موظف</option>

                               @foreach ( $employees as  $employee )
                               <option value="{{$employee->id}}">{{$employee->emp_name}}</option>
                               @endforeach
                          
                            </select>
                        </div>
                        <div class="col-md-4">
                            <label for="inputPassword4" class="form-label"> تاريخ الغياب*</label>
                            <input type="date" class="form-control" name="absence_date" id="absence_date" value="{{date('Y-m-d')}}">
                        </div>
                 
                        <div class="col-md-4">
                            <label for="inputPassword4" class="form-label"> رقم الامر*</label>
                            <input type="text" class="form-control" name="absence_number" id="thanks_number">
                        </div>
                        <div class="col-md-4">
                            <label for="inputPassword4" class="form-label"> عدد ايام الغياب (يوم)*</label>
                            <input type="text" class="form-control" name="days_count" id="days_count" value="1">
                        </div>
                   
                
                      
                  
                        <div class="col-md-4">
                            <label for="inputPassword4" class="form-label">الملاحضات </label>
                            <input type="text" class="form-control" name="notes" id="notes">
                        </div>
                     
                      
                     
                    

                        <div class="col-12">
                            <button class="btn btn-primary" type="submit">
                                حفظ
                            </button>
                        </div>

                    </form>
                </div>
            </div>

        </div>
        <div class="container mt-5 ">

          @if ($msg = Session::get('success'))
          <div class="alert alert-success mt-2" role="alert">
              {{ $msg }}
              <!-- Close button for the alert -->
              <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
          </div>
          @endif


               
    </section>
    @else
    @php
        header('Location: ' . URL::to('/home'));
        exit();
    @endphp

@endif
@endsection
