
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark menu">
     
          <!-- Brand -->
          <!-- <a class="navbar-brand" href="#">نظام ادارة معلومات الموظفين</a> -->
      
          <!-- Toggle button for mobile view -->
          <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav"
                  aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
          </button>
      
          <!-- Navbar items and search box -->
          <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ms-auto">
              <li class="nav-item active">
                <a class="nav-link" href="{{route('home')}}">الرئيسية</a>
              </li>
            <li class="nav-item dropdown">
                <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                  الملفات التعريفية
                </a>
                <ul class="dropdown-menu" style="text-align:center">
                  {{-- <li><a class="dropdown-item" href="{{route('def-degree.index')}}"> تعريف الدرجات والعلاوات</a></li> --}}
                  <li><a class="dropdown-item" href="{{route('department.index')}}"> تعريف مواقع العمل </a></li>
                  <li><a class="dropdown-item" href="{{route('jobdes.index')}}">تعريف العناوين الوظيفية </a></li>
                  <li><a class="dropdown-item" href="{{route('education.index')}}">تعريف التحصيل الدراسي </a></li>
                  <li><a class="dropdown-item" href="{{route('vacation.index')}}">تعريف الاجازات </a></li>
                  <li><a class="dropdown-item" href="{{route('alert.create')}}">فترة التنبيه</a></li>
                  {{-- <li><a class="dropdown-item" href="../pages/takeout.php">سند اخراج</a></li>
                  <li><hr class="dropdown-divider"></li>
                  <li><a class="dropdown-item" href="../pages/view_insert.php">عرض سندات الادخال</a></li>
                  <li><a class="dropdown-item" href="../pages/view_takeout.php">عرض سندات الاخراج</a></li>
                  <li><hr class="dropdown-divider"></li>
                  <li><a class="dropdown-item" href="../pages/quantity_report.php">جرد المخزن</a></li> --}}
                </ul>
              </li>
              
              <li class="nav-item dropdown">
                <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                  الموظفين
                </a>
                <ul class="dropdown-menu" style="text-align:center">
                  <li><a class="dropdown-item" href="{{route('employee.create')}}">فتح ملف موظف</a></li>
                  <li><a class="dropdown-item" href="{{route('employee.index')}}">عرض الموظفين</a></li>
               
                </ul>
              </li>
              <li class="nav-item dropdown">
                <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                  التشكرات والعقوبات
                </a>
                <ul class="dropdown-menu" style="text-align:center">
                  <li><a class="dropdown-item" href="{{route('thank.create')}}">التشكرات</a></li>
                  <li><a class="dropdown-item" href="{{route('penalty.create')}}">العقوبات</a></li>
               
                </ul>
              </li>
              <li class="nav-item dropdown">
                <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                   الاجازات والغيابات
                </a>
                <ul class="dropdown-menu" style="text-align:center">
                  <li><a class="dropdown-item" href="{{route('vac.create')}}">الاجازات</a></li>
                  <li><a class="dropdown-item" href="{{route('absence.create')}}">الغيابات</a></li>
               
                </ul>
              </li>
           
              <li class="nav-item dropdown">
                <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                   التقارير
                </a>
                <ul class="dropdown-menu" style="text-align:center">
                  <li><a class="dropdown-item" href="{{route('bonusreport')}}">تقرير العلاوات المستحقة</a></li>
                  <li><a class="dropdown-item" href="{{route('proreport')}}">تقرير الترفيعات المستحقة</a></li>
                  <li><a class="dropdown-item" href="{{route('retreport')}}">تقرير استحقاق التقاعد </a></li>
               
                </ul>
              </li>
           
              <li class="nav-item dropdown">
                <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                   التنبيهات
                </a>
                <ul class="dropdown-menu" style="text-align:center">
                  <li><a class="dropdown-item" href="{{route('bonusalert')}}">تنبيهات العلاوات المستحقة</a></li>
                  <li><a class="dropdown-item" href="{{route('proalert')}}">تنبيهات الترفيعات المستحقة</a></li>
                  <li><a class="dropdown-item" href="{{route('retalert')}}">تنبيهات استحقاق التقاعد </a></li>
               
                </ul>
              </li>
              <li class="nav-item dropdown">
                <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                   المستخدمين
                </a>
                <ul class="dropdown-menu" style="text-align:center">
                  <li><a class="dropdown-item" href="{{route('admin.create')}}">اضافة مستخدمين</a></li>
                  <li><a class="dropdown-item" href="{{route('admin.index')}}">عرض المستخدمين</a></li>
              
                </ul>
              </li>
           
          
         
              
            
              <li class="nav-item">
                <form method="POST" action="{{route('logout') }}">
                    @csrf
                    <button type="submit" class="nav-link" style="border: none; background: none; cursor: pointer;">تسجيل خروج</button>
                </form>
            </li>
              {{-- <div id="movetxt">تصميم وبرمجة قسم تكنولوجيا المعلومات - المبرمج محمد عزيز  -  المبرمج احمد امجد</div> --}}
              <!-- Add more navbar items as needed -->
      
              <!-- Search box -->
              <!-- <li class="nav-item">
                <form class="d-flex" method="POST" action="search.php" >
                  <input  class="form-control me-2" type="search" placeholder="ابحث عن  ..." aria-label="Search"  name="keyword">
                  <button class="btn btn-success" type="submit">بحث</button>
                </form>
              </li> -->
            </ul>
          </div>
        </div>
      </nav