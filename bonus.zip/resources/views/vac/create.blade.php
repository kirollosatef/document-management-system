@extends('define-degree.layout')
@section('content')
@if (session('admin_role')[9] == 1)
    <section>



        <div class="container mt-4  ">
            @if ($errors->any())
                <div class="alert alert-danger">
                    <ul>
                        @foreach ($errors->all() as $error)
                            <li>{{ $error }}</li>
                        @endforeach
                    </ul>
                </div>
            @endif
            <div class="card shadow">
                <div class="card-header">
                    <h3>الاجازات</h3>
                </div>
                <div class="card-body">
                    <form class="row g-3" method="POST" id="insertform" action="{{ route('vac.store') }}">
                        @csrf
                        @method('POST')
                        <div class="col-md-4" style="margin-top:20px ;">
                            <label for="selectData" class="mb-1">اسم الموظف*</label>
                            <select class="form-control select2 custom-select-height" name="emp_id" id="emp_id">
                                <option selected disabled>اختر موظف</option>
                                @foreach ($employees as $employee)
                                    <option value="{{ $employee->id }}">{{ $employee->emp_name }}</option>
                                @endforeach

                            </select>
                        </div>
                        <div class="col-md-4" style="margin-top:20px ;">
                            <label for="selectData" class="mb-1">نوع الاجازة*</label>
                            <select class="form-control select2 custom-select-height" name="vac_type" id="vac_type">
                                <option selected disabled>اختر نوع الاجازة</option>
                                @foreach ($vactions as $vaction)
                                    <option value="{{ $vaction->id }}">{{ $vaction->vacation_type }}</option>
                                @endforeach

                            </select>
                        </div>
                        <div class="col-md-4">
                            <label for="inputPassword4" class="form-label"> تاريخ الكتاب*</label>
                            <input type="date" class="form-control" name="vac_date" id="vac_date"
                                value="{{ date('Y-m-d') }}">
                        </div>
                        <div class="col-md-4" style="margin-top:20px ;">
                            <label for="selectData" class="mb-1">تاخير العلاوة والترفيع*</label>
                            <select class="form-control select2 custom-select-height" name="delay" id="delay">
                                <option value="1">نعم</option>
                                <option value="0">لا</option>


                            </select>
                        </div>
                        <div class="col-md-4">
                            <label for="inputPassword4" class="form-label"> رقم الامر*</label>
                            <input type="text" class="form-control" name="vac_number" id="vac_number">
                        </div>
                        <div class="col-md-4">
                            <label for="inputPassword4" class="form-label"> تاخير (يوم)*</label>
                            <input type="text" class="form-control" name="days_count" id="days_count" value="0">
                        </div>




                        <div class="col-md-4">
                            <label for="inputPassword4" class="form-label">الملاحضات *</label>
                            <input type="text" class="form-control" name="notes" id="notes">
                        </div>





                        <div class="col-12">
                            <button class="btn btn-primary" type="submit">
                                حفظ
                            </button>
                        </div>

                    </form>
                </div>
            </div>

        </div>
        <div class="container mt-5 ">

            @if ($msg = Session::get('success'))
                <div class="alert alert-success mt-2" role="alert">
                    {{ $msg }}
                    <!-- Close button for the alert -->
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
            @endif



    </section>
    @else
    @php
        header('Location: ' . URL::to('/home'));
        exit();
    @endphp

@endif
@endsection
