@extends('define-degree.layout')
@section('content')
    <section>



        <div class="container mt-4  ">
            @if ($errors->any())
                <div class="alert alert-danger">
                    <ul>
                        @foreach ($errors->all() as $error)
                            <li>{{ $error }}</li>
                        @endforeach
                    </ul>
                </div>
            @endif
            <div class="card shadow">
                <div class="card-header">
                    <h3>اصدار ترفيع</h3>
                    <h3 class="text-danger">{{$emp_name}}</h3>
                </div>
                <div class="card-body">
                    <form class="row g-3" method="POST" id="insertform" action="{{route('gpro.store')}}">
                        @csrf
                        @method('POST')
                        <div class="col-md-4" style="margin-top:20px ;">
                            <label for="selectData" class="mb-1"> معرف الموظف*</label>
                            <input type="text" class="form-control" name="emp_id" id="emp_id" value="{{$emp_id}}" readonly>

                            {{-- <select class="form-control select2 custom-select-height" name="emp_id" id="emp_id">
                                <option selected disabled>اختر موظف</option>
                               @foreach ( $employees as  $employee )
                               <option value="{{$employee->id}}">{{$employee->emp_name}}</option>
                               @endforeach
                          
                            </select> --}}
                        </div>
                        <div class="col-md-4">
                            <label for="inputPassword4" class="form-label"> تاريخ الامر*</label>
                            <input type="date" class="form-control" name="gpro_date" id="gbonus_date" value="{{date('Y-m-d')}}">
                        </div>
                     
                        <div class="col-md-4">
                            <label for="inputPassword4" class="form-label"> رقم الامر*</label>
                            <input type="text" class="form-control" name="gpro_number" id="gbonus_number">
                        </div>
                  
                
                      
                  
                 
                      
                     
                    

                        <div class="col-12">
                            <button class="btn btn-primary" type="submit">
                                اصدار
                            </button>
                        </div>

                    </form>
                </div>
            </div>

        </div>
        <div class="container mt-5 ">

          @if ($msg = Session::get('success'))
          <div class="alert alert-success mt-2" role="alert">
              {{ $msg }}
              <!-- Close button for the alert -->
              <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
          </div>
          @endif


               
    </section>
@endsection
