@extends('define-degree.layout')
@section('content')
    <section>



        <div class="container mt-4  ">
            @if ($errors->any())
                <div class="alert alert-danger">
                    <ul>
                        @foreach ($errors->all() as $error)
                            <li>{{ $error }}</li>
                        @endforeach
                    </ul>
                </div>
            @endif
            <div class="card shadow">
                <div class="card-header">
                    <h3>تعريف الدرجات والعلاوات</h3>
                </div>
                <div class="card-body">
                    <form class="row g-3" method="POST" id="insertform" action="{{ route('def-degree.store') }}">
                        @csrf
                        @method('POST')
                        <div class="col-md-6" style="margin-top:20px ;">
                            <label for="selectData" class="mb-1">الدرجة*</label>
                            <select class="form-control select2 custom-select-height" name="degree" id="degree">
                                <option value="1">1</option>
                                <option value="2">2</option>
                                <option value="3">3</option>
                                <option value="4">4</option>
                                <option value="5">5</option>
                                <option value="6">6</option>
                                <option value="7">7</option>
                                <option value="8">8</option>
                                <option value="9">9</option>
                                <option value="10">10</option>
                            </select>
                        </div>
                        <div class="col-md-6">
                            <label for="inputPassword4" class="form-label"> العلاوة*</label>
                            <input type="number" class="form-control" name="bonus" id="bonus">
                        </div>

                        <div class="col-2">
                            <button class="btn btn-primary" type="submit">
                                حفظ
                            </button>
                        </div>

                    </form>
                </div>
            </div>

        </div>
        <div class="container mt-5 ">

          @if ($msg = Session::get('success'))
          <div class="alert alert-success mt-2" role="alert">
              {{ $msg }}
              <!-- Close button for the alert -->
              <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
          </div>
          @endif



          <div class="row justify-content-center">
              <div class="table-responsive table-scroll" data-mdb-perfect-scrollbar="true" style="position: relative;">
                  <table class="table table-striped mb-0 table-bordered">
                      <thead class="table-dark">
                          <tr>
                         
                              <th scope="col">الدرجة الوظيفية</th>
                              <th scope="col"> مقدار العلاوة</th>
                 

                              <th scope="col"></th>
                              
                            
                             

                          </tr>
                      </thead>
                      <tbody>
                          @foreach ($degrees as $degree)
                          <tr>
                              <td>
                                 {{$degree->degree}}
                              </td>
                              <td>
                                 {{$degree->bonus}}
                              </td>
                            
                            
                             
                        
                              <td>
                                  <form action="{{route('def-degree.destroy',$degree->id)}}" method="post">
                                      @method('delete')
                                      @csrf
                                     
                                      <input class="form-control btn btn-danger " type="submit" value="حذف" id="deleteform" onclick="return confirmDelete();">
                                      
                                  </form>
                              </td>
                          </tr>
                          @endforeach
                         




                      </tbody>
                      
                  </table>
                  
              
                  
                
              </div>
              {{-- @isset($name)
                  @empty(!$name)
                      {{ $name }}
                  @endempty
              @endisset --}}


              <div>
              </div>
              {{-- <div class="mt-2">
                  {{$emps->links('pagination::bootstrap-5')}}
              </div> --}}
               
    </section>
@endsection
