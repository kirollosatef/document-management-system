<?php

namespace App\Http\Controllers;

use App\Models\Gbonus;
use Carbon\Carbon;
use Illuminate\Http\Request;
use App\Models\Employee;

class GbonusController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        $customMessages = [
            'emp_id.required' => 'اسم الموظف مطلوب',
            'gbonus_date.required' => 'حقل تاريخ اصدار العلاوة مطلوب',
            'gbonus_date.date' => 'حقل  تاريخ اصدار العلاوة  يجب ان يكون تاريخ',
            'gbonus_number.required' => 'رقم الامر مطلوب',

        ];

        $request->validate([
            'emp_id' => 'required|numeric',
            'gbonus_date' => 'required|date',
            'gbonus_number' => 'required',
            // 'notes' => 'required',




        ], $customMessages);

        $inputs = $request->all();
        Gbonus::create($inputs);
        $employee = Employee::findOrFail($request->emp_id);
        $new_bonus_after = Carbon::parse($request->gbonus_date)->addYears(1);
        // dd( $employee->stage );
        /////////////////////////// calculate degree and stage after bonus 
        if ($employee->stage == 11) {
            $after_stage = 1;
            $after_degree = $employee->degree - 1;
        } else {
            $after_stage = $employee->stage + 1;
            $after_degree = $employee->degree;
        }
        if ($employee->new_stage == 11) {
            $after_new_stage = 1;
            $after_new_degree = $employee->new_degree - 1;
        } else {
            $after_new_stage = $employee->new_stage + 1;
            $after_new_degree = $employee->new_degree;
        }
        ///////////////////////////////// calculate salary after bonus
        $degreeConfig = [
            "10" => ["baseSalary" => 170000, "yearIncrement" => 3000],
            "9" => ["baseSalary" => 210000, "yearIncrement" => 3000],
            "8" => ["baseSalary" => 260000, "yearIncrement" => 3000],
            "7" => ["baseSalary" => 296000, "yearIncrement" => 6000],
            "6" => ["baseSalary" => 362000, "yearIncrement" => 6000],
            "5" => ["baseSalary" => 429000, "yearIncrement" => 6000],
            "4" => ["baseSalary" => 509000, "yearIncrement" => 8000],
            "3" => ["baseSalary" => 600000, "yearIncrement" => 10000],
            "2" => ["baseSalary" => 723000, "yearIncrement" => 17000],
            "1" => ["baseSalary" => 910000, "yearIncrement" => 20000],
          
            
        ];
         
        if ($after_degree == 10 ) {
            $after_salary =$degreeConfig[10]['baseSalary']+$degreeConfig[10]['yearIncrement']* ($after_stage-1);

        } elseif ($after_degree == 9 ) {
            $after_salary=$degreeConfig[9]['baseSalary']+$degreeConfig[9]['yearIncrement']* ($after_stage-1);
        } 
         elseif ($after_degree == 8 ) {
            $after_salary=$degreeConfig[8]['baseSalary']+$degreeConfig[8]['yearIncrement']* ($after_stage-1);
        } 
         elseif ($after_degree == 7 ) {
            $after_salary=$degreeConfig[7]['baseSalary']+$degreeConfig[7]['yearIncrement']* ($after_stage-1);
        } 
         elseif ($after_degree == 6 ) {
            $after_salary=$degreeConfig[6]['baseSalary']+$degreeConfig[6]['yearIncrement']* ($after_stage-1);
        } 
         elseif ($after_degree == 5 ) {
            $after_salary=$degreeConfig[5]['baseSalary']+$degreeConfig[5]['yearIncrement']* ($after_stage-1);
        } 
         elseif ($after_degree == 4 ) {
            $after_salary=$degreeConfig[4]['baseSalary']+$degreeConfig[4]['yearIncrement']* ($after_stage-1);
        } 
         elseif ($after_degree == 3 ) {
            $after_salary=$degreeConfig[3]['baseSalary']+$degreeConfig[3]['yearIncrement']* ($after_stage-1);
        } 
         elseif ($after_degree == 2 ) {
            $after_salary=$degreeConfig[2]['baseSalary']+$degreeConfig[2]['yearIncrement']* ($after_stage-1);
        } 
         elseif ($after_degree == 1 ) {
            $after_salary=$degreeConfig[1]['baseSalary']+$degreeConfig[1]['yearIncrement']* ($after_stage-1);
        } 
        ///////////////////////////////// calculate new salary after bonus
        if ($after_new_degree == 10 ) {
            $after_new_salary =$degreeConfig[10]['baseSalary']+$degreeConfig[10]['yearIncrement']* ($after_new_stage-1);

        } elseif ($after_new_degree == 9 ) {
            $after_new_salary =$degreeConfig[9]['baseSalary']+$degreeConfig[9]['yearIncrement']* ($after_new_stage-1);
        } 
         elseif ($after_new_degree == 8 ) {
            $after_new_salary =$degreeConfig[8]['baseSalary']+$degreeConfig[8]['yearIncrement']* ($after_new_stage-1);
        } 
         elseif ($after_new_degree == 7 ) {
            $after_new_salary =$degreeConfig[7]['baseSalary']+$degreeConfig[7]['yearIncrement']* ($after_new_stage-1);
        } 
         elseif ($after_new_degree == 6 ) {
            $after_new_salary =$degreeConfig[6]['baseSalary']+$degreeConfig[6]['yearIncrement']* ($after_new_stage-1);
        } 
         elseif ($after_new_degree == 5 ) {
            $after_new_salary =$degreeConfig[5]['baseSalary']+$degreeConfig[5]['yearIncrement']* ($after_new_stage-1);
        } 
         elseif ($after_new_degree == 4 ) {
            $after_new_salary =$degreeConfig[4]['baseSalary']+$degreeConfig[4]['yearIncrement']* ($after_new_stage-1);
        } 
         elseif ($after_new_degree == 3 ) {
            $after_new_salary =$degreeConfig[3]['baseSalary']+$degreeConfig[3]['yearIncrement']* ($after_new_stage-1);
        } 
         elseif ($after_new_degree == 2 ) {
            $after_new_salary =$degreeConfig[2]['baseSalary']+$degreeConfig[2]['yearIncrement']* ($after_new_stage-1);
        } 
         elseif ($after_new_degree == 1 ) {
            $after_new_salary =$degreeConfig[1]['baseSalary']+$degreeConfig[1]['yearIncrement']* ($after_new_stage-1);
        } 
      

        $employee->update([
            'degree' => $after_degree,
            'stage' => $after_stage,
            'salary'=> $after_salary,
            'new_salary'=> $after_new_salary,
            'new_degree' => $after_new_degree,
            'new_stage' => $after_new_stage,
            'last_bonus' => $request->gbonus_date,
            'new_bonus' => $new_bonus_after
        ]);
        // $this->updateEmployeeAttributes($employee);

        return redirect()->route('employee.index')->with('success', 'تم اصدار العلاوة بنجاح وتحديث البيانات');
    }

    /**
     * Display the specified resource.
     */
    public function show()
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(Gbonus $gbonus)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, Gbonus $gbonus)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(Gbonus $gbonus)
    {
        //
    }
    public function gbonusCreate($emp_id, $emp_name)
    {


        return view('gbonus.create')
            ->with(['emp_id' => $emp_id])
            ->with(['emp_name' => $emp_name])
        ;
    }

    public function viewGbonus(string $emp_id, string $emp_name)
    {
        $gbonuses = Gbonus::where('emp_id', $emp_id)->orderBy('created_at')->paginate(10);
        return view('gbonus.view', compact('gbonuses'))
            ->with('emp_name', $emp_name)
            ->with('emp_id', $emp_id);


    }

}
