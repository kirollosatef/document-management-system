<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\DefineDegree;

class DefineDegreeController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        $degrees = DefineDegree::orderBy('degree')->get();
        // dd($degree);
       return view('define-degree.index',compact('degrees'));

    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        $customMessages = [
            'degree.required' => 'يرجى إدخال قيمة للدرجة.',
            'degree.numeric' => 'يجب أن تكون قيمة الدرجة رقمًا.',
            'degree.unique' => 'الدرجة موجودة بالفعل في قاعدة البيانات.',
            'bonus.required' => 'يرجى إدخال قيمة العلاوه.',
            'bonus.numeric' => 'يجب أن تكون قيمة العلاوه رقمًا.',
        ];
        $request->validate([
            'degree' => 'required|numeric|unique:define_degrees,degree',
            'bonus' => 'required|numeric',
        ], $customMessages);
        

        $inputs=$request->all();
        DefineDegree::create($inputs);

        return redirect()->route('def-degree.index')->with('success','تم الاضافة  بنجاح');
    
    }

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
       $degree=DefineDegree::findOrFail($id);
       $degree->delete();
       return redirect()->route('def-degree.index')->with('success','تم الحذف  بنجاح');
    }
}
