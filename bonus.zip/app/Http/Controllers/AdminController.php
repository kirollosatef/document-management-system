<?php

namespace App\Http\Controllers;

use App\Models\Admin;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Hash;
use Log;
use Session;

class AdminController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        $admins=Admin::orderBy('created_at')->get();
        return view('auth.view',compact('admins'));
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        return view('auth.addusers');
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        // Validate the form data
        $customMessages = [
            'username.required' => 'اسم المستخدم مطلوب',
            'username.unique' => 'اسم المستخدم موجود مسبقا في قاعدة البيانات',
            'password.required' => 'حقل كلمة المرور مطلوب',
           
        ];
        $validatedData = $request->validate([
            'username' => 'required|unique:admins',
            'password' => 'required',
            // Add validation rules for permissions checkboxes if needed
        ] ,$customMessages);

        // Process permissions checkboxes
        $permissions = '';
        for ($i = 1; $i <= 18; $i++) {
            $permissions .= $request->has($i) ? '1' : '0';
        }

        // Create a new user
        $admin = new Admin();
        $admin->username = $validatedData['username'];
        $admin->password = bcrypt($validatedData['password']);
        $admin->role = $permissions; // Save permissions as a single string
        // Save other user details as needed

        // Save the user
        $admin->save();

        // Redirect back with success message
        return redirect()->back()->with('success', 'تم اضافة المستخدم بنجاح');
    }

    /**
     * Display the specified resource.
     */
    public function show(Admin $admin)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(Admin $admin)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, Admin $admin)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        $user = Admin::findOrFail($id);
        $user->delete();
        return redirect()->route('admin.index')->with('success','تم الحذف  بنجاح');

    }

    public function login()
    {
        return view('auth.login');
    }

    public function authenticate(Request $request)
    {
        $credentials = $request->only('username', 'password');

        $user = Admin::where('username', $credentials['username'])->first();


        if ($user && Hash::check($credentials['password'], $user->password)) {

            $res = Auth::guard('admin')->loginUsingId($user->id);

            if ($res) {
                $role = $user->role;
                session(['admin_role' => $role]);
                return redirect()->intended('/home');
            }
        }

        // Log authentication failure


        return redirect()->back()->withErrors(['error' => 'خطا في اسم المستخدم او كلمة المرور']);
    }
    public function logout()
    {
        // Clear all session data
        Auth::guard('admin')->logout();



        return redirect('/');
    }

}