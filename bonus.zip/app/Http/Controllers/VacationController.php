<?php

namespace App\Http\Controllers;

use App\Models\Vacation;
use Illuminate\Http\Request;

class VacationController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        $vacations = Vacation::orderBy('vacation_type')->get();
        
        return view('vacation.index', compact('vacations'));
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        $customMessages = [
            'vacation_type.required' => 'يرجى إدخال قيمةالاجازة.',
        
            'vacation_type.unique' => ' نوع الاجازة موجود بالفعل في قاعدة البيانات.',
            'vacation_type.regex' => 'يجب أن يحتوي الحقل على نص عربي فقط.',
        ];

        $request->validate([
            'vacation_type' => 'required|unique:vacations,vacation_type|regex:/^[\p{Arabic}\s]+$/u',
        ], $customMessages);
        
        // Retrieve all input data from the request
        $inputs = $request->all();
        
        // Create a new Vacation model instance and assign values
        $vacation = new Vacation();
        $vacation->vacation_type = $inputs['vacation_type']; 
        
        // Check if the checkbox is checked
        // $isChecked = $request->has('delay') ? 1 : 0;
        $vacation->delay = 1;
        
        // Save the new Vacation instance
        $vacation->save();
        
        // Redirect with success message
        return redirect()->route('vacation.index')->with('success', 'تم الاضافة بنجاح');
        
    }

    /**
     * Display the specified resource.
     */
    public function show(Vacation $vacation)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(Vacation $vacation)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, Vacation $vacation)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy($id)
    {
        $vacation=Vacation::findOrFail($id);
        $vacation->delete();
        return redirect()->route('vacation.index')->with('success','تم الحذف  بنجاح');
    }
}
