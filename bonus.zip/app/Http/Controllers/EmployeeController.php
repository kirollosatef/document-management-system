<?php

namespace App\Http\Controllers;

use App\Models\Admin;
use App\Models\Employee;
use App\Models\Penalty;
use App\Models\Vac;
use Illuminate\Http\Request;
use App\Models\Jobdes;
use App\Models\Education;
use App\Models\Department;
use Carbon\Carbon;
use App\Models\Alert;
use App\Models\Thank;


class EmployeeController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        // $degrees = DefineDegree::orderBy('degree')->get();
        // dd($degree);
        $employees =Employee::orderBy('created_at')->paginate(9);
       return view('employee.index',compact('employees'));
        
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        $jobdeses=Jobdes::orderBy('jobdes')->get();
        $educations=Education::orderBy('education')->get();
        $departments=Department::orderBy('dep_name')->get();
        // dd($jobdeses);
        return view('employee.create')
        ->with(['jobdeses' => $jobdeses])
        ->with(['educations'=>$educations])
        ->with(['departments'=> $departments])
        ;
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        $customMessages = [
            'emp_number.required' => 'رقم الموظف مطلوب',
            'emp_number.numeric' => 'حقل رقم الموظف يجب ان يكون رقما',
            'emp_number.unique' => 'رقم الموظف المدخل موجود مسبقا في قاعدة البيانات',
            'emp_name.required' => 'اسم الموظف مطلوب',
            'emp_name.regex' => 'اسم الموظف يجب ان يكون باللغة العربية فقط',
            'emp_name.unique' => 'اسم الموظف مكرر في قاعدة البيانات',
            'jobdes.required' => 'العنوان الوظيفي مطلوب',
            'jobdes.regex' => 'العنوان الوظيفي يجب ان يكون بالعربية',
            'birth_day.required' => 'حقل المواليد مطلوب',
            'birth_day.date' => 'حقل المواليد يجب ان يكون تاريخ',
            'salary.required' => 'حقل الراتب الحالي مطلوب',
            'salary.numeric' => 'حقل الراتب الحالي يجب ان يكون رقما',
            'start_date.required' => 'حقل تاريخ المباشرة مطلوب',
            'start_date.date' => 'حقل تاريخ المباشرة يجب ان يكون تاريخ',
            'last_bonus.required' => 'اخر ترفيع مطلوب',
            'last_bonus.date' => 'اخر ترفيع يجب ان يكون تاريخ',
            'last_pro.required' => 'اخر ترفيع مطلوب',
            'last_pro.date' => 'اخر ترفيع يجب ان يكون تاريخ',
            'new_degree.required' => 'حقل الدرجة الجديده مطلوب',
            'new_degree.numeric' => 'حقل الدرجة الجديدة يجب ان يكون رقما',
            'new_stage.required' => 'حقل المرحلة الجديدة مطلوب',
            'new_stage.numeric' => 'حقل المرحلة الجديدة يجب ان يكون رقما',
            'new_salary.required' => 'حقل الراتب الجديد مطلوب',
            'new_salary.numeric' => 'حقل الراتب الجديد يجب ان يكون رقما',
            'new_bonus.required' => 'حقل العلاوة الجديد مطلوب',
            'new_bonus.date' => 'حقل العلاوة الجديد يجب ان يكون تاريخ',
            'new_pro.required' => 'حقل الترفيع الجديد مطلوب',
            'new_pro.date' => 'حقل الترفيع الجديد يجب ان يكون تاريخ',
        ];
        
        $request->validate([
            'emp_number' => 'required|numeric|unique:employees,emp_number',
            'emp_name' => 'required|regex:/^[\p{Arabic}\s]+$/u|unique:employees,emp_name|max:50',
            'jobdes' => 'required|regex:/^[\p{Arabic}\s]+$/u',
            'education' => 'required',
            'department' => 'required',
            'birth_day' => 'required|date',
            'degree' => 'required|numeric',
            'stage' => 'required|numeric',
            'salary' => 'required|numeric', 
            'start_date' => 'required|date',
            'emp_type' => 'required|regex:/^[\p{Arabic}\s]+$/u',
            'last_bonus' => 'required|date',
            'last_pro' => 'required|date',
            'new_degree' => 'required|numeric',
            'new_stage' => 'required|numeric',
            'new_salary' => 'required|numeric',
            'new_bonus' => 'required|date',
            'new_pro' => 'required|date',
          
            

        ], $customMessages);

        $inputs=$request->all();
        Employee::create($inputs);

        return redirect()->route('employee.index')->with('success','تم الاضافة  بنجاح');
    }

    /**
     * Display the specified resource.
     */
    public function show(Employee $employee)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit($id)
    {
        $jobdeses=Jobdes::orderBy('jobdes')->get();
        $educations=Education::orderBy('education')->get();
        $departments=Department::orderBy('dep_name')->get();
        $employee=Employee::findOrFail($id);
        return view('employee.edit',compact('employee'))
        ->with(['jobdeses' => $jobdeses])
        ->with(['educations'=>$educations])
        ->with(['departments'=> $departments]);
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, $id)
    {
        $customMessages = [
            'emp_number.required' => 'رقم الموظف مطلوب',
            'emp_number.numeric' => 'حقل رقم الموظف يجب ان يكون رقما',
            'emp_number.unique' => 'رقم الموظف المدخل موجود مسبقا في قاعدة البيانات',
            'emp_name.required' => 'اسم الموظف مطلوب',
            'emp_name.regex' => 'اسم الموظف يجب ان يكون باللغة العربية فقط',
            'emp_name.unique' => 'اسم الموظف مكرر في قاعدة البيانات',
            'jobdes.required' => 'العنوان الوظيفي مطلوب',
            'jobdes.regex' => 'العنوان الوظيفي يجب ان يكون بالعربية',
            'birth_day.required' => 'حقل المواليد مطلوب',
            'birth_day.date' => 'حقل المواليد يجب ان يكون تاريخ',
            'salary.required' => 'حقل الراتب الحالي مطلوب',
            'salary.numeric' => 'حقل الراتب الحالي يجب ان يكون رقما',
            'start_date.required' => 'حقل تاريخ المباشرة مطلوب',
            'start_date.date' => 'حقل تاريخ المباشرة يجب ان يكون تاريخ',
            'last_bonus.required' => 'اخر ترفيع مطلوب',
            'last_bonus.date' => 'اخر ترفيع يجب ان يكون تاريخ',
            'last_pro.required' => 'اخر ترفيع مطلوب',
            'last_pro.date' => 'اخر ترفيع يجب ان يكون تاريخ',
            'new_degree.required' => 'حقل الدرجة الجديده مطلوب',
            'new_degree.numeric' => 'حقل الدرجة الجديدة يجب ان يكون رقما',
            'new_stage.required' => 'حقل المرحلة الجديدة مطلوب',
            'new_stage.numeric' => 'حقل المرحلة الجديدة يجب ان يكون رقما',
            'new_salary.required' => 'حقل الراتب الجديد مطلوب',
            'new_salary.numeric' => 'حقل الراتب الجديد يجب ان يكون رقما',
            'new_bonus.required' => 'حقل العلاوة الجديد مطلوب',
            'new_bonus.date' => 'حقل العلاوة الجديد يجب ان يكون تاريخ',
            'new_pro.required' => 'حقل الترفيع الجديد مطلوب',
            'new_pro.date' => 'حقل الترفيع الجديد يجب ان يكون تاريخ',
        ];
        
        $request->validate([
            'emp_number' => 'required|numeric',
            'emp_name' => 'required|regex:/^[\p{Arabic}\s]+$/u|max:50',
            'jobdes' => 'required|regex:/^[\p{Arabic}\s]+$/u',
            'education' => 'required',
            'department' => 'required',
            'birth_day' => 'required|date',
            'degree' => 'required|numeric',
            'stage' => 'required|numeric',
            'salary' => 'required|numeric', 
            'start_date' => 'required|date',
            'emp_type' => 'required|regex:/^[\p{Arabic}\s]+$/u',
            'last_bonus' => 'required|date',
            'last_pro' => 'required|date',
            'new_degree' => 'required|numeric',
            'new_stage' => 'required|numeric',
            'new_salary' => 'required|numeric',
            'new_bonus' => 'required|date',
            'new_pro' => 'required|date',
          
            

        ], $customMessages);
        $employee=Employee::findOrFail($id);
        $input=$request->all();
        $employee->update( $input);
        return redirect()->route('employee.index')->with('success','تم تحديث البيانات بنجاح');
       
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy($id)
    {
        $emp=Employee::findOrFail($id);
        $emp->delete();
        return redirect()->route('employee.index')->with('success','تم الحذف  بنجاح');

        
    }

    public function empSearch(Request $request){
        
        $employees =Employee::where('emp_name','like',"%$request->keyword%")
        ->orWhere('jobdes','like',"%$request->keyword%")
        ->orWhere('education','like',"%$request->keyword%")
        ->orWhere('department','like',"%$request->keyword%")

        ->paginate(9);

        return view('employee.index',compact('employees'));

    }

    public function bonusReport(Request $request){
        if(isset($request->from) &&isset($request->to))
        {
            $employees =Employee::whereBetween('new_bonus', [$request->from, $request->to])->get();
        return view('reports.bonus_report',compact('employees'))
        ->with(['from' => $request->from])
        ->with(['to'=>$request->to]);
        }
 
        return view('reports.bonus_report');
    }
    public function bonusReportPrint(Request $request){
        if(isset($request->from) &&isset($request->to))
        {
            $employees =Employee::whereBetween('new_bonus', [$request->from, $request->to])->get();
        return view('reports.bonus_report_print',compact('employees'))
        ->with(['from' => $request->from])
        ->with(['to'=>$request->to]);
        }
 
        return view('reports.bonus_report');
    }
    public function proReport(Request $request){
        if(isset($request->from) &&isset($request->to))
        {
            $employees =Employee::whereBetween('new_pro', [$request->from, $request->to])->get();
        return view('reports.pro_report',compact('employees'))
        ->with(['from' => $request->from])
        ->with(['to'=>$request->to]);
        }
 
        return view('reports.pro_report');
    }
    public function proReportPrint(Request $request){
        if(isset($request->from) &&isset($request->to))
        {
            $employees =Employee::whereBetween('new_pro', [$request->from, $request->to])->get();
        return view('reports.pro_report_print',compact('employees'))
        ->with(['from' => $request->from])
        ->with(['to'=>$request->to]);
        }
 
        return view('reports.pro_report');
    }
    public function retReport(Request $request){
        if(isset($request->from) &&isset($request->to))
        {
            $employees =Employee::whereBetween('retire_date', [$request->from, $request->to])->get();
        return view('reports.retire_report',compact('employees'))
        ->with(['from' => $request->from])
        ->with(['to'=>$request->to]);
        }
 
        return view('reports.retire_report');
    }
    public function retReportPrint(Request $request){
        if(isset($request->from) &&isset($request->to))
        {
            $employees =Employee::whereBetween('retire_date', [$request->from, $request->to])->get();
        return view('reports.retire_report_print',compact('employees'))
        ->with(['from' => $request->from])
        ->with(['to'=>$request->to]);
        }
 
        return view('reports.retire_report');
    }

    public function home(){
        $emp=Employee::count();
        $thanks=Thank::count();
        $pals=Penalty::count();
        $vacs=Vac::count();
        $deps=Department::count();
        $jobs=Jobdes::count();
        $eds=Education::count();
        $admins=Admin::count();
        return view('home.home')
        ->with(['emp'=>$emp])
        ->with(['thanks'=>$thanks])
        ->with(['pals'=>$pals])
        ->with(['vacs'=>$vacs])
        ->with(['deps'=>$deps])
        ->with(['jobs'=>$jobs])
        ->with(['eds'=>$eds])
        ->with(['admins'=>$admins]);
    }

    public function bonusAlert() {
      
        $alertDays = Alert::latest()->first();
        if($alertDays){
            $alertDays=$alertDays->alertdays;

        }else{
            $alertDays=0;

        }
    
        $currentDate = Carbon::now();
        $targetDate = $currentDate->addDays($alertDays)->format('Y-m-d');
    
        $employees = Employee::where('new_bonus', '<=', $targetDate)->get();
        // dd($employees);
        
       
    
        return view('alerts.bonus_alert', compact('employees'));
    }
    public function proAlert() {
      
        $alertDays = Alert::latest()->first();
        if($alertDays){
            $alertDays=$alertDays->alertdays;

        }else{
            $alertDays=0;

        }
    
        $currentDate = Carbon::now();
        $targetDate = $currentDate->addDays($alertDays)->format('Y-m-d');
    
        $employees = Employee::where('new_pro', '<=', $targetDate)->get();
        // dd($employees);
        
       
    
        return view('alerts.pro_alert', compact('employees'));
    }
    public function retAlert() {
      
        $alertDays = Alert::latest()->first();
        if($alertDays){
            $alertDays=$alertDays->alertdays;

        }else{
            $alertDays=0;

        }
    
        $currentDate = Carbon::now();
        $targetDate = $currentDate->addDays($alertDays)->format('Y-m-d');
    
        $employees = Employee::where('retire_date', '<=', $targetDate)->get();
        // dd($employees);
        
       
    
        return view('alerts.ret_alert', compact('employees'));
    }

}
