<?php

namespace App\Http\Controllers;

use App\Models\Absence;
use Illuminate\Http\Request;
use App\Models\Employee;
use Carbon\Carbon;


class AbsenceController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        $employees = Employee::orderBy('emp_name')->get();
        return view('abcence.create')
            ->with(['employees' => $employees]);
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        $customMessages = [
            'emp_id.required' => 'اسم الموظف مطلوب',
            'absence_date.required' => 'تاريخ الغياب مطلوب',
            'absence_date.date' => 'حقل تاريخ الغياب يجب ان يكون تاريخ',
            'absence_number.required' => 'رقم الامر مطلوب',
            'days_count.required' => 'عدد ايام الغياب مطلوب',
            'days_count.numeric' => 'عدد ايام الغياب يجب ان يكون رقما',
        ];

        $request->validate([
            'emp_id' => 'required|numeric',
            'absence_date' => 'required|date',
            'absence_number' => 'required',
            'days_count' => 'required|numeric',
            // 'notes' => 'required',




        ], $customMessages);

        $inputs = $request->all();
        Absence::create($inputs);
        $employee = Employee::findOrFail($request->emp_id);
        $this->updateEmployeeAttributes($employee);

        return redirect()->route('employee.index')->with('success', 'تم اضافة الغياب بنجاح وتحديث البيانات');

    }
    private function updateEmployeeAttributes(Employee $employee)
    {
        $days_count_bonus = $employee->thanks()->where('thanks_date', '>', $employee->last_bonus)->sum('days_count');
        $days_count_penalty = $employee->penalties()->where('penalty_date', '>', $employee->last_bonus)->sum('days_count');
        $days_count_absence = $employee->absences()->where('absence_date', '>', $employee->last_bonus)->sum('days_count');
        $days_count_vac = $employee->vacs()->where('vac_date', '>', $employee->last_bonus)->where('delay',1)->sum('days_count');
    
        $new_bonus = Carbon::parse($employee->last_bonus)->addYears(1)->subDays($days_count_bonus)->addDays($days_count_penalty)->addDays($days_count_absence)->addDays($days_count_vac);
    
        $days_count_pro_bonus = $employee->thanks()->where('thanks_date', '>', $employee->last_pro)->sum('days_count');
        $days_count_pro_penalty = $employee->penalties()->where('penalty_date', '>', $employee->last_pro)->sum('days_count');
        $days_count_pro_absence = $employee->absences()->where('absence_date', '>', $employee->last_pro)->sum('days_count');
        $days_count_pro_vac= $employee->vacs()->where('vac_date', '>', $employee->last_pro)->where('delay',1)->sum('days_count');
    
        $new_pro = Carbon::parse($employee->last_pro)->addYears($employee->degree < 6 ? 5 : 4)->subDays($days_count_pro_bonus)->addDays($days_count_pro_penalty)->addDays($days_count_pro_absence)->addDays($days_count_pro_vac);
    
        $employee->update([
            'new_bonus' => $new_bonus,
            'new_pro' => $new_pro,
        ]);
    }

    /**
     * Display the specified resource.
     */
    public function show(Absence $absence)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(Absence $absence)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, Absence $absence)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy($absence_id,$emp_id)
    {
        $absence= Absence::findOrFail($absence_id);

        // Retrieve the related Employee model
        
        // Delete the Thank model
        $absence->delete();
        // $employee = $thank->employee;

        // Recalculate days_count based on remaining Thanks associated with the Employee
        
      $employee = Employee::findOrFail($emp_id);
        $this->updateEmployeeAttributes($employee);
        return redirect()->route('employee.index')->with('success', 'تم حذف الغياب بنجاح وتحديث البيانات');
    }
    public function viewAbsence(string $id, string $emp_name){
        $abcences =Absence::where('emp_id', $id)->orderBy('created_at')->paginate(10);
       
        return view('abcence.view', compact('abcences'))
        ->with('emp_name', $emp_name)
        ->with('emp_id',$id);


    }
}
