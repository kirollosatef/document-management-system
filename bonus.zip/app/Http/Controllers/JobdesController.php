<?php

namespace App\Http\Controllers;

use App\Models\Jobdes;
use Illuminate\Http\Request;

class JobdesController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        $jobdeses=Jobdes::orderBy('jobdes')->get();
        return view('jobdes.index',compact('jobdeses'));
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        $customMessages = [
            'jobdes.required' => 'يرجى إدخال قيمة العنوان الوظيفي.',
            'jobdes.regex' => 'يجب أن يحتوي العنوان الوظيفي على نص عربي فقط.',
            'jobdes.unique' => ' العنوان الوظيفي موجود بالفعل في قاعدة البيانات.',
        ];
        
        $request->validate([
            'jobdes' => 'required|regex:/^[\p{Arabic}\s]+$/u|unique:jobdes,jobdes',
        ], $customMessages);

        $inputs=$request->all();
        Jobdes::create($inputs);

        return redirect()->route('jobdes.index')->with('success','تم الاضافة  بنجاح');
    }

    /**
     * Display the specified resource.
     */
    public function show(Jobdes $jobdes)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(Jobdes $jobdes)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, Jobdes $jobdes)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        $jobdes=Jobdes::findOrFail($id);
        $jobdes->delete();
        return redirect()->route('jobdes.index')->with('success','تم الحذف  بنجاح');
    }
}
