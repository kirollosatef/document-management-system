<?php

namespace App\Http\Controllers;

use App\Models\Alert;
use Illuminate\Http\Request;

class AlertController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
       
        $alerts = Alert::latest()->first();
        
       return view('alerts.alertdays',compact('alerts'));
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
{
    $customMessages = [
        'alertdays.required' => 'يرجى إدخال قيمة  .',
        'alertdays.numeric' => 'يجب ان يكون الحقل قيمة رقمية فقط.',
        // 'dep_name.unique' => 'موقع العمل موجود بالفعل في قاعدة البيانات.',
    ];
    
    $request->validate([
        'alertdays' => 'required|numeric',
    ], $customMessages);

    $inputs = $request->all();
    Alert::create($inputs);
    
    // Retrieve the latest alert
    $alerts = Alert::latest()->first();

    return view('alerts.alertdays')
        ->with(['alerts' => $alerts])
        ->with('success', 'تم الاضافة بنجاح');
}

    /**
     * Display the specified resource.
     */
    public function show(Alert $alert)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(Alert $alert)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, Alert $alert)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(Alert $alert)
    {
        //
    }
}
