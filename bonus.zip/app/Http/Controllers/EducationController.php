<?php

namespace App\Http\Controllers;

use App\Models\Education;
use Illuminate\Http\Request;

class EducationController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        $educations=Education::orderBy('education')->get();
        return view('education.index',compact('educations'));
    }

    
    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        $customMessages = [
            'education.required' => 'يرجى إدخال قيمة التحصيل الدراسي .',
            'education.regex' => 'يجب أن يحتوي التحصيل الدراسي على نص عربي فقط.',
            'education.unique' => 'التحصيل الدراسي موجود بالفعل في قاعدة البيانات.',
        ];
        
        $request->validate([
            'education' => 'required|regex:/^[\p{Arabic}\s]+$/u|unique:education,education',
        ], $customMessages);

        $inputs=$request->all();
        Education::create($inputs);

        return redirect()->route('education.index')->with('success','تم الاضافة  بنجاح');
    }

    /**
     * Display the specified resource.
     */
    public function show(Education $education)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(Education $education)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, Education $education)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        $education=Education::findOrFail($id);
        $education->delete();
        return redirect()->route('education.index')->with('success','تم الحذف  بنجاح');
    }
}
