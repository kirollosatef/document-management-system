<?php

namespace App\Http\Controllers;

use App\Models\Gpro;
use Illuminate\Http\Request;
use App\Models\Employee;
use Carbon\Carbon;


class GproController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        $customMessages = [
            'emp_id.required' => 'اسم الموظف مطلوب',
            'gpro_date.required' => 'حقل تاريخ اصدار الترفيع مطلوب',
            'gpro_date.date' => 'حقل تاريخ اصدار الترفيع  يجب ان يكون تاريخ',
            'gpro_number.required' => 'رقم الامر مطلوب',
        ];

        $request->validate([
            'emp_id' => 'required|numeric',
            'gpro_date' => 'required|date',
            'gpro_number' => 'required',
            // 'notes' => 'required',




        ], $customMessages);

        $inputs = $request->all();
        Gpro::create($inputs);
        $employee = Employee::findOrFail($request->emp_id);
     

        $after_degree= $employee->degree-1;
        $after_stage=1;
        $after_new_degree=$employee->degree-1;
        $after_new_stage=$after_stage+1;
        //////////////////////////////////////
        if( $after_degree <6){
            $new_pro_after=Carbon::parse($request->gpro_date)->addYears(5);

        }else{
            $new_pro_after=Carbon::parse($request->gpro_date)->addYears(4);
        }
        ///////////////////// calculate salary
        $degreeConfig = [
            "10" => ["baseSalary" => 170000, "yearIncrement" => 3000],
            "9" => ["baseSalary" => 210000, "yearIncrement" => 3000],
            "8" => ["baseSalary" => 260000, "yearIncrement" => 3000],
            "7" => ["baseSalary" => 296000, "yearIncrement" => 6000],
            "6" => ["baseSalary" => 362000, "yearIncrement" => 6000],
            "5" => ["baseSalary" => 429000, "yearIncrement" => 6000],
            "4" => ["baseSalary" => 509000, "yearIncrement" => 8000],
            "3" => ["baseSalary" => 600000, "yearIncrement" => 10000],
            "2" => ["baseSalary" => 723000, "yearIncrement" => 17000],
            "1" => ["baseSalary" => 910000, "yearIncrement" => 20000],
          
            
        ];
        if ($after_degree == 10 ) {
            $after_salary =$degreeConfig[10]['baseSalary']+$degreeConfig[10]['yearIncrement']* ($after_stage-1);

        } elseif ($after_degree == 9 ) {
            $after_salary=$degreeConfig[9]['baseSalary']+$degreeConfig[9]['yearIncrement']* ($after_stage-1);
        } 
         elseif ($after_degree == 8 ) {
            $after_salary=$degreeConfig[8]['baseSalary']+$degreeConfig[8]['yearIncrement']* ($after_stage-1);
        } 
         elseif ($after_degree == 7 ) {
            $after_salary=$degreeConfig[7]['baseSalary']+$degreeConfig[7]['yearIncrement']* ($after_stage-1);
        } 
         elseif ($after_degree == 6 ) {
            $after_salary=$degreeConfig[6]['baseSalary']+$degreeConfig[6]['yearIncrement']* ($after_stage-1);
        } 
         elseif ($after_degree == 5 ) {
            $after_salary=$degreeConfig[5]['baseSalary']+$degreeConfig[5]['yearIncrement']* ($after_stage-1);
        } 
         elseif ($after_degree == 4 ) {
            $after_salary=$degreeConfig[4]['baseSalary']+$degreeConfig[4]['yearIncrement']* ($after_stage-1);
        } 
         elseif ($after_degree == 3 ) {
            $after_salary=$degreeConfig[3]['baseSalary']+$degreeConfig[3]['yearIncrement']* ($after_stage-1);
        } 
         elseif ($after_degree == 2 ) {
            $after_salary=$degreeConfig[2]['baseSalary']+$degreeConfig[2]['yearIncrement']* ($after_stage-1);
        } 
         elseif ($after_degree == 1 ) {
            $after_salary=$degreeConfig[1]['baseSalary']+$degreeConfig[1]['yearIncrement']* ($after_stage-1);
        } 

         ///////////////////////////////// calculate new salary after bonus
         if ($after_new_degree == 10 ) {
            $after_new_salary =$degreeConfig[10]['baseSalary']+$degreeConfig[10]['yearIncrement']* ($after_new_stage-1);

        } elseif ($after_new_degree == 9 ) {
            $after_new_salary =$degreeConfig[9]['baseSalary']+$degreeConfig[9]['yearIncrement']* ($after_new_stage-1);
        } 
         elseif ($after_new_degree == 8 ) {
            $after_new_salary =$degreeConfig[8]['baseSalary']+$degreeConfig[8]['yearIncrement']* ($after_new_stage-1);
        } 
         elseif ($after_new_degree == 7 ) {
            $after_new_salary =$degreeConfig[7]['baseSalary']+$degreeConfig[7]['yearIncrement']* ($after_new_stage-1);
        } 
         elseif ($after_new_degree == 6 ) {
            $after_new_salary =$degreeConfig[6]['baseSalary']+$degreeConfig[6]['yearIncrement']* ($after_new_stage-1);
        } 
         elseif ($after_new_degree == 5 ) {
            $after_new_salary =$degreeConfig[5]['baseSalary']+$degreeConfig[5]['yearIncrement']* ($after_new_stage-1);
        } 
         elseif ($after_new_degree == 4 ) {
            $after_new_salary =$degreeConfig[4]['baseSalary']+$degreeConfig[4]['yearIncrement']* ($after_new_stage-1);
        } 
         elseif ($after_new_degree == 3 ) {
            $after_new_salary =$degreeConfig[3]['baseSalary']+$degreeConfig[3]['yearIncrement']* ($after_new_stage-1);
        } 
         elseif ($after_new_degree == 2 ) {
            $after_new_salary =$degreeConfig[2]['baseSalary']+$degreeConfig[2]['yearIncrement']* ($after_new_stage-1);
        } 
         elseif ($after_new_degree == 1 ) {
            $after_new_salary =$degreeConfig[1]['baseSalary']+$degreeConfig[1]['yearIncrement']* ($after_new_stage-1);
        } 
      
        
        
        // dd( $employee );
        $employee->update([
            'degree' => $after_degree,
            'stage' => $after_stage,
            'salary'=> $after_salary,
            'new_salary'=> $after_new_salary,
            'new_degree' => $after_new_degree,
            'new_stage' => $after_new_stage,
            'last_pro'=>$request->gpro_date,
            'new_pro'=>$new_pro_after
        ]);
        // $this->updateEmployeeAttributes($employee);

        return redirect()->route('employee.index')->with('success', 'تم اصدار الترفيع بنجاح وتحديث البيانات');
    }

    /**
     * Display the specified resource.
     */
    public function show(Gpro $gpro)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(Gpro $gpro)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, Gpro $gpro)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(Gpro $gpro)
    {
        //
    }

    public function gproCreate(string $emp_id, string $emp_name){
  
        return view('gpro.create')
        ->with(['emp_id'=>$emp_id])
        ->with(['emp_name'=>$emp_name])
        ;
    }

    public function viewGpro(string $emp_id, string $emp_name){
        $gpros = Gpro::where('emp_id', $emp_id)->orderBy('created_at')->paginate(10);
        return view('gpro.view', compact('gpros'))
        ->with('emp_name', $emp_name)
        ->with('emp_id', $emp_id);

    }
}
