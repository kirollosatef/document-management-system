<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Penalty extends Model
{
    use HasFactory;
    protected $table = "penalties";
    protected $fillable = ["emp_id", "penalty_date", "penalty_type", "penalty_number", "days_count", "notes"];
    public function employee()
    {
        return $this->belongsTo(Employee::class);
    }
}
