<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Gpro extends Model
{
    use HasFactory;
    protected $table="gpros";
    protected $fillable=["emp_id","gpro_date","gpro_number"];
    public function employee()
    {
        return $this->belongsTo(Employee::class);
    }
}
