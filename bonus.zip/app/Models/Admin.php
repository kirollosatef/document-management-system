<?php

namespace App\Models;

use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Notifications\Notifiable;

class Admin extends Authenticatable
{
    use HasFactory, Notifiable;

    // Specify the table name if it's different from the default
    protected $table = 'admins';

    // Fillable attributes if you're using mass assignment
    protected $fillable = [
        'username', 'password', 'role',
    ];

    // Hidden attributes if you don't want them to be visible in JSON output
    protected $hidden = [
        'password', 'remember_token',
    ];
}