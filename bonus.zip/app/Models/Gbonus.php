<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Gbonus extends Model
{
    use HasFactory;
    protected $table="gbonuses";
    protected $fillable=["emp_id","gbonus_date","gbonus_number"];
    public function employee()
    {
        return $this->belongsTo(Employee::class);
    }
}

