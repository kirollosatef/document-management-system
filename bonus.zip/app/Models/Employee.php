<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Employee extends Model
{

    use HasFactory;
    protected $table = "employees";
    protected $fillable = [
        'emp_number',
        'emp_name',
        'jobdes',
        'education',
        'department',
        'birth_day',
        'degree',
        'stage',
        'salary',
        'start_date',
        'emp_type',
        'last_bonus',
        'last_pro',
        'new_degree',
        'new_stage',
        'new_salary',
        'new_bonus',
        'new_pro',
        'retire_date'
    ];

    public function thanks()
    {
        return $this->hasMany(Thank::class,'emp_id');
    }
    public function penalties()
    {
        return $this->hasMany(Penalty::class,'emp_id');
    }
    public function absences()
    {
        return $this->hasMany(Absence::class,'emp_id');
    }
    public function vacs()
    {
        return $this->hasMany(Vac::class,'emp_id');
    }
    public function gbonuses()
    {
        return $this->hasMany(Gbonus::class,'emp_id');
    }
    public function gpros()
    {
        return $this->hasMany(Gpro::class,'emp_id');
    }




}
