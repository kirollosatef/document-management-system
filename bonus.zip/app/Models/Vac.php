<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Vac extends Model
{
    use HasFactory;
    protected $table = "vacs";
    protected $fillable = ["emp_id","vac_type" ,"vac_date","delay","vac_number","days_count", "notes"];
    public function employee()
    {
        return $this->belongsTo(Employee::class);
    }
}
