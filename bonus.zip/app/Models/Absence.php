<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Absence extends Model
{
    use HasFactory;
    protected $table = "absences";
    protected $fillable = ["emp_id", "absence_date","absence_number", "days_count", "notes"];
    public function employee()
    {
        return $this->belongsTo(Employee::class);
    }
}
