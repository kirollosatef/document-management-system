<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Thank extends Model
{
    use HasFactory;
    protected $table = "thanks";
    protected $fillable = ["emp_id", "thanks_date", "thanks_type", "thanks_number", "days_count", "notes"];
    public function employee()
    {
        return $this->belongsTo(Employee::class);
    }
}
