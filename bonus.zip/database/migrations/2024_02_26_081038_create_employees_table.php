<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('employees', function (Blueprint $table) {
            $table->id();
            $table->bigInteger('emp_number');
            $table->string('emp_name');
            $table->string('jobdes');
            $table->string('education');
            $table->string('department');
            $table->date('birth_day');
            $table->integer('degree');
            $table->integer('stage');
            $table->integer('salary');
            $table->date('start_date');
            $table->string('emp_type');
            $table->date('last_bonus');
            $table->date('last_pro');
            $table->integer('new_degree');
            $table->integer('new_stage');
            $table->integer('new_salary');
            $table->date('new_bonus');
            $table->date('new_pro');
            $table->date('retire_date');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('employees');
    }
};
