


document.addEventListener("DOMContentLoaded", function () {

    $(document).ready(function () {
        initializeSelect2();
    });

    function initializeSelect2() {
        $('.select2').select2();
    }

    /////////////////////////////////


    const birthDateInput = document.getElementById('birth_day');
    const retireDateInput = document.getElementById('retire_date');

    // Function to calculate retirement date
    function calculateRetirementDate() {
        // Get the value of the birth date input field
        const birthDateValue = birthDateInput.value;

        // Check if the birth date input field has a value
        if (birthDateValue) {
            // Get the value of the birth date input field as a Date object
            const birthDate = new Date(birthDateValue);

            // Calculate retirement date by adding 63 years to the birth date
            const retirementDate = new Date(birthDate.getFullYear() + 63, birthDate.getMonth(), birthDate.getDate());

            // Format retirement date as yyyy-mm-dd
            const formattedRetirementDate = retirementDate.toISOString().split('T')[0];

            // Set the value of the retire date input field to the calculated retirement date
            retireDateInput.value = formattedRetirementDate;
        }
    }

    // Calculate retirement date on page load
    calculateRetirementDate();

    // Add event listener to the birth date input field
    birthDateInput.addEventListener('change', calculateRetirementDate);


    ///////////////////////////////////////////////////////////
    const lastBonusInput = document.getElementById('last_bonus');
    const lastProInput = document.getElementById('last_pro');
    const newBonusInput = document.getElementById('new_bonus');
    const newProInput = document.getElementById('new_pro');
    const degreeInput = document.getElementById('degree');

    // Function to add years to a given date
    function addYearsToDate(date, years) {
        const newDate = new Date(date);
        newDate.setFullYear(newDate.getFullYear() + years);
        return newDate.toISOString().split('T')[0];
    }

    // Function to calculate new bonus date
    function calculateNewBonusDate() {
        const lastBonusDate = lastBonusInput.value;
        if (lastBonusDate !== '') {
            const newBonusDate = addYearsToDate(lastBonusDate, 1);
            newBonusInput.value = newBonusDate;
        }
    }

    // Function to calculate new promotion date based on degree
    function calculateNewPromotionDate() {
        const lastProDate = lastProInput.value;
        const degree = parseInt(degreeInput.value);
        if (lastProDate !== '') {
            let yearsToAdd = 0;
            switch (degree) {
                case 10:
                case 9:
                case 8:
                case 7:
                case 6:
                    yearsToAdd = 4;
                    break;
                case 5:
                case 4:
                case 3:
                case 2:
                    yearsToAdd = 5;
                    break;
                case 1:
                    yearsToAdd = 0;
                    break;
                default:
                    yearsToAdd = 0;
            }
            const newProDate = addYearsToDate(lastProDate, yearsToAdd);
            newProInput.value = newProDate;
        }
    }

    // Event listeners for input changes
    lastBonusInput.addEventListener('change', calculateNewBonusDate);
    lastProInput.addEventListener('change', calculateNewPromotionDate);
    degreeInput.addEventListener('change', calculateNewPromotionDate);

    // Initial calculation when the page loads
    calculateNewBonusDate();
    calculateNewPromotionDate();
    /////////////////////////////////////////////////////////////End of New bonus and new pro
    // Select elements
    var degreeSelect = document.getElementById("degree");
    var stageSelect = document.getElementById("stage");
    var newDegreeInput = document.getElementById("new_degree");
    var newStageInput = document.getElementById("new_stage");

    // Add change event listener to degree and stage selects
    degreeSelect.addEventListener("change", function () {
        updateNewDegreeAndStage();
    });

    stageSelect.addEventListener("change", function () {
        updateNewDegreeAndStage();
    });

    // Function to update new degree and new stage fields
    function updateNewDegreeAndStage() {
        var oldDegree = parseInt(degreeSelect.value);
        var oldStage = parseInt(stageSelect.value);

        var newDegree;
        var newStage;

        // Determine new degree
        if (oldDegree === 1 && oldStage === 11) {
            newDegree = oldDegree;
        } else if (oldStage === 11) {
            newDegree = oldDegree - 1;
        } else {
            newDegree = oldDegree;
        }

        // Determine new stage
        if (oldDegree === 1 && oldStage === 11) {
            newStage = oldStage;
        } else if (oldStage === 11) {
            newStage = 1;
        } else {
            newStage = oldStage + 1;
        }

        // Update new degree and new stage fields
        newDegreeInput.value = newDegree;
        newStageInput.value = newStage;

        // Manually trigger the calculation of the new salary
        calculateNewSalary();
    }

});





var degreeConfig = {
    "10": { baseSalary: 170000, yearIncrement: 3000 },
    "9": { baseSalary: 210000, yearIncrement: 3000 },
    "8": { baseSalary: 260000, yearIncrement: 3000 },
    "7": { baseSalary: 296000, yearIncrement: 6000 },
    "6": { baseSalary: 362000, yearIncrement: 6000 },
    "5": { baseSalary: 429000, yearIncrement: 6000 },
    "4": { baseSalary: 509000, yearIncrement: 8000 },
    "3": { baseSalary: 600000, yearIncrement: 10000 },
    "2": { baseSalary: 723000, yearIncrement: 17000 },
    "1": { baseSalary: 910000, yearIncrement: 20000 },


    // Add more degrees and their configurations as needed
};

function calculateSalary() {
    var degree = document.getElementById('degree').value;
    var stage = parseInt(document.getElementById('stage').value);

    var config = degreeConfig[degree];

    var baseSalary = config.baseSalary;
    var yearIncrement = config.yearIncrement;

    var salary = baseSalary + yearIncrement * (stage - 1);

    document.getElementById('salary').value = salary;
}

function calculateNewSalary() {
    console.log("Script executing...");
    var newDegree = document.getElementById('new_degree').value;
    var newStage = parseInt(document.getElementById('new_stage').value);


    var baseSalary = degreeConfig[newDegree].baseSalary;
    var yearIncrement = degreeConfig[newDegree].yearIncrement;


    var newSalary = baseSalary + yearIncrement * (newStage - 1);


    document.getElementById('new_salary').value = newSalary;
}
document.getElementById('degree').addEventListener('change', calculateSalary);
document.getElementById('stage').addEventListener('change', calculateSalary);
document.getElementById('new_degree').addEventListener('change', calculateNewSalary);
document.getElementById('new_stage').addEventListener('change', calculateNewSalary);

calculateSalary();
calculateNewSalary();

///////////////////////////////////////////////////////////////////////////

