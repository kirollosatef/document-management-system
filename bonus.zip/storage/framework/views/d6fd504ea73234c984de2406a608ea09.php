
<?php $__env->startSection('content'); ?>

    <?php if(session('admin_role')[0] == 1): ?>


        <section>



            <div class="container mt-4  ">
                <?php if($errors->any()): ?>
                    <div class="alert alert-danger">
                        <ul>
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                <?php endif; ?>
                <div class="card shadow">
                    <div class="card-header">
                        <h3>تعريف مواقع العمل</h3>
                    </div>
                    <div class="card-body">
                        <form class="row g-3" method="POST" id="insertform" action="<?php echo e(route('department.store')); ?>">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('POST'); ?>

                            <div class="col-md-6">
                                <label for="inputPassword4" class="form-label"> موقع العمل*</label>
                                <input type="text" class="form-control" name="dep_name" id="dep_name">
                            </div>

                            <div class="col-12">
                                <button class="btn btn-primary" type="submit">
                                    حفظ
                                </button>
                            </div>

                        </form>
                    </div>
                </div>

            </div>
            <div class="container mt-5 ">

                <?php if($msg = Session::get('success')): ?>
                    <div class="alert alert-success mt-2" role="alert">
                        <?php echo e($msg); ?>

                        <!-- Close button for the alert -->
                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>
                <?php endif; ?>



                <div class="row justify-content-center">
                    <div class="table-responsive table-scroll" data-mdb-perfect-scrollbar="true"
                        style="position: relative;">
                        <table class="table table-striped mb-0 table-bordered">
                            <thead class="table-dark">
                                <tr>

                                    <th scope="col"> مواقع العمل</th>



                                    <th scope="col"></th>




                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $departments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $department): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td>
                                            <?php echo e($department->dep_name); ?>

                                        </td>
                                        



                                        
                                        <td>
                                            <form action="<?php echo e(route('department.destroy', $department->id)); ?>"
                                                method="post">
                                                <?php echo method_field('delete'); ?>
                                                <?php echo csrf_field(); ?>

                                                <input class="form-control btn btn-danger " type="submit" value="حذف"
                                                    id="deleteform" onclick="return confirmDelete();">

                                            </form>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>





                            </tbody>

                        </table>




                    </div>
                    


                    <div>
                    </div>
                    

        </section>
    <?php else: ?>
        <?php
            header('Location: ' . URL::to('/home'));
            exit();
        ?>

    <?php endif; ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('define-degree.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\bonus\resources\views/department/index.blade.php ENDPATH**/ ?>