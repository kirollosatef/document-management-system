
<?php $__env->startSection('content'); ?>
    <section>



        <div class="container mt-4  ">
            <?php if($errors->any()): ?>
                <div class="alert alert-danger">
                    <ul>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            <?php endif; ?>
            <div class="card shadow">
                <div class="card-header">
                    <h3>اصدار علاوة</h3>
                    <h3 class="text-danger"><?php echo e($emp_name); ?></h3>
                </div>
                <div class="card-body">
                    <form class="row g-3" method="POST" id="insertform" action="<?php echo e(route('gbonus.store')); ?>">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('POST'); ?>
                        <div class="col-md-4" style="margin-top:20px ;">
                            <label for="selectData" class="mb-1"> معرف الموظف*</label>
                            <input type="text" class="form-control" name="emp_id" id="emp_id" value="<?php echo e($emp_id); ?>" readonly>

                            
                        </div>
                        <div class="col-md-4">
                            <label for="inputPassword4" class="form-label"> تاريخ الامر*</label>
                            <input type="date" class="form-control" name="gbonus_date" id="gbonus_date" value="<?php echo e(date('Y-m-d')); ?>">
                        </div>
                     
                        <div class="col-md-4">
                            <label for="inputPassword4" class="form-label"> رقم الامر*</label>
                            <input type="text" class="form-control" name="gbonus_number" id="gbonus_number">
                        </div>
                  
                
                      
                  
                 
                      
                     
                    

                        <div class="col-12">
                            <button class="btn btn-primary" type="submit">
                                اصدار
                            </button>
                        </div>

                    </form>
                </div>
            </div>

        </div>
        <div class="container mt-5 ">

          <?php if($msg = Session::get('success')): ?>
          <div class="alert alert-success mt-2" role="alert">
              <?php echo e($msg); ?>

              <!-- Close button for the alert -->
              <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
          </div>
          <?php endif; ?>


               
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('define-degree.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\bonus\resources\views/gbonus/create.blade.php ENDPATH**/ ?>