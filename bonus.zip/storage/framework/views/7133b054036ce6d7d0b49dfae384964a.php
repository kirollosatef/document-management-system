
<?php $__env->startSection('content'); ?>
    <section>



        <div class="container mt-4  ">
            <?php if($errors->any()): ?>
                <div class="alert alert-danger">
                    <ul>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            <?php endif; ?>


        </div>
        <div class="col-md-12 bg-light py-1 mb-2">
            <div class="pt-1 ">
                <h2 class="text-center">تقرير الترفيعات المستحقة</h2>
                <h5 class="text-center "> من <?php echo e(isset($from) ? $from : date('Y-m-d')); ?> </h5>
                <h5 class="text-center ">  الى <?php echo e(isset($to) ? $to : date('Y-m-d')); ?> </h5>
               


            </div>
        </div>

        
        <div class="container-fluid mt-3 ">

            <?php if($msg = Session::get('success')): ?>
                <div class="alert alert-success mt-2" role="alert">
                    <?php echo e($msg); ?>

                    <!-- Close button for the alert -->
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
            <?php endif; ?>
            <table id="dtBasicExample" class="table table-striped table-bordered table-sm" cellspacing="0" width="100%">
                <thead class="">
                    <tr>
                        <th class="th-sm">رقم الموظف</th>
                        <th class="th-sm">اسم الموظف</th>
                       
                     
                        <th class="th-sm">مكان العمل</th>
                     
                        <th class="th-sm">الدرجة</th>
                        <th class="th-sm">المرحلة</th>
                        <th class="th-sm">الراتب الحالي</th>
                   
                        <th class="th-sm">نوع القيد</th>
                        <th class="th-sm">اخر ترفيع</th>
                     
                        <th class="th-sm">الدرجة الجديدة</th>
                        <th class="th-sm">المرحلة الجديدة</th>
                        <th class="th-sm">الراتب الجديد</th>
                        <th class="th-sm">تاريخ الترفيع الجديد</th>
                    
                  
                        
                    </tr>
                </thead>
                <?php if(isset($from) && isset($to)): ?>
                    <tbody>
                        <?php $__currentLoopData = $employees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td>
                                    <?php echo e($employee->emp_number); ?>

                                </td>
                                <td>
                                    <?php echo e($employee->emp_name); ?>

                                </td>


                            

                                <td>
                                    <?php echo e($employee->department); ?>

                                </td>

                               

                                <td>
                                    <?php echo e($employee->degree); ?>

                                </td>

                                <td>
                                    <?php echo e($employee->stage); ?>

                                </td>
                                <td>
                                    <?php echo e($employee->salary); ?>

                                </td>
                               
                                <td>
                                    <?php echo e($employee->emp_type); ?>

                                </td>
                                <td class="text-danger " style="font-weight: bold">
                                    <?php echo e($employee->last_pro); ?>

                                </td>
                               

                                <td>
                                    <?php echo e($employee->new_degree); ?>

                                </td>

                                <td>
                                    <?php echo e($employee->new_stage); ?>

                                </td>

                                <td>
                                    <?php echo e($employee->new_salary); ?>

                                </td>

                                
                                <td class="text-danger " style="font-weight: bold">
                                    <?php echo e($employee->new_pro); ?>

                                </td>
                            



                                
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>





                    </tbody>
                <?php endif; ?>

                <tfoot>




                </tfoot>
            </table>
          
                
         



        </div>


        <div>
        </div>


    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('reports.printlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\bonus\resources\views/reports/pro_report_print.blade.php ENDPATH**/ ?>