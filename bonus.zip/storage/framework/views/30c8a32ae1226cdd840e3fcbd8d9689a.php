

<?php $__env->startSection('content'); ?>

<section class="vh-100 gradient-custom">
    <div class="container py-5 h-100">
        <div class="row d-flex justify-content-center align-items-center h-100">
            <div class="col-12 col-md-8 col-lg-6 col-xl-5">
                <div class="card bg-dark text-white" style="border-radius: 1rem;">
                    <div class="card-body p-5 text-center">

                        <div class="mb-md-5 mt-md-4 pb-5">

                            <h2 class="fw-bold mb-2 text-uppercase"> نظام ادارة العلاوات والترفيعات</h2>
                            <p class="text-white-50 mb-5">قم بادخال اسم المستخدم وكلمة المرور</p>
                            <form action="<?php echo e(route('authenticate')); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('POST'); ?>

                                <div class="form-outline form-white mb-4">
                                    <label class="form-label" for="typeEmailX">اسم المستخدم</label>
                                    <input type="text" id="user" class="form-control form-control-lg"
                                        name="username" />
                                </div>

                                <div class="form-outline form-white mb-4">
                                    <label class="form-label" for="typePasswordX">كلمة المرور</label>
                                    <input type="password" id="typePasswordX" class="form-control form-control-lg"
                                        name="password" />
                                </div>

                                <!-- <p class="small mb-5 pb-lg-2"><a class="text-white-50" href="#!">Forgot password?</a></p> -->

                                <button class="btn btn-outline-warning btn-lg px-5" type="submit">دخول</button>
                                <?php if($errors->has('error')): ?>
                                <div class="alert alert-danger mt-3">
                                    <?php echo e($errors->first('error')); ?>

                                </div>
                            <?php endif; ?>
                            </form>
                    


   
                        </div>

                        <div>
                            <p class="mb-0"> تصميم وبرمجة قسم تكنولوجيا المعلومات - المبرمج محمد عزيز
                            </p>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('define-degree.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\bonus\resources\views/auth/login.blade.php ENDPATH**/ ?>