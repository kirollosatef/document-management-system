
<?php $__env->startSection('content'); ?>
<?php if(session('admin_role')[14] == 1): ?>
    <section>



        <div class="container mt-4  ">
            <?php if($errors->any()): ?>
                <div class="alert alert-danger">
                    <ul>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            <?php endif; ?>


        </div>
        <div class="col-md-12 bg-danger py-1 mb-2">
            <div class="pt-1 ">
                <h2 class="text-center text-light">تنبيهات العلاوات المستحقة</h2>
               


            </div>
        </div>

        
        <div class="container-fluid mt-3 ">

            <?php if($msg = Session::get('success')): ?>
                <div class="alert alert-success mt-2" role="alert">
                    <?php echo e($msg); ?>

                    <!-- Close button for the alert -->
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
            <?php endif; ?>
            <table id="dtBasicExample" class="table table-striped table-bordered table-sm" cellspacing="0" width="100%">
                <thead class="table-dark">
                    <tr>
                        <th class="th-sm">رقم الموظف</th>
                        <th class="th-sm">اسم الموظف</th>
                       
                     
                        <th class="th-sm">مكان العمل</th>
                     
                        <th class="th-sm">الدرجة</th>
                        <th class="th-sm">المرحلة</th>
                        <th class="th-sm">الراتب الحالي</th>
                   
                        <th class="th-sm">نوع القيد</th>
                        <th class="th-sm">اخر علاوة</th>
                     
                        <th class="th-sm">الدرجة الجديدة</th>
                        <th class="th-sm">المرحلة الجديدة</th>
                        <th class="th-sm">الراتب الجديد</th>
                        <th class="th-sm">تاريخ العلاوة الجديدة</th>
                  
                        <th class="th-sm"></th>
                        <th class="th-sm"></th>
                        <th class="th-sm"></th>
                        <th class="th-sm"></th>
                        <th class="th-sm"></th>
                        <th class="th-sm"></th>
                    </tr>
                </thead>
              
                    <tbody>
                        <?php $__currentLoopData = $employees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td>
                                    <?php echo e($employee->emp_number); ?>

                                </td>
                                <td>
                                    <?php echo e($employee->emp_name); ?>

                                </td>


                            

                                <td>
                                    <?php echo e($employee->department); ?>

                                </td>

                               

                                <td>
                                    <?php echo e($employee->degree); ?>

                                </td>

                                <td>
                                    <?php echo e($employee->stage); ?>

                                </td>
                                <td>
                                    <?php echo e($employee->salary); ?>

                                </td>
                               
                                <td>
                                    <?php echo e($employee->emp_type); ?>

                                </td>
                                <td class="text-danger " style="font-weight: bold">
                                    <?php echo e($employee->last_bonus); ?>

                                </td>
                               

                                <td>
                                    <?php echo e($employee->new_degree); ?>

                                </td>

                                <td>
                                    <?php echo e($employee->new_stage); ?>

                                </td>

                                <td>
                                    <?php echo e($employee->new_salary); ?>

                                </td>

                                <td class="text-danger " style="font-weight: bold">
                                    <?php echo e($employee->new_bonus); ?>

                                </td>
                            



                                <td>
                                    <a class= "btn btn-primary"
                                        href="<?php echo e(route('viewThanks', ['id' => $employee->id, 'emp_name' => $employee->emp_name])); ?>"  style="width: 90px ;height: 62px;">عرض
                                        التشكرات</a>
                                </td>
                                <td>
                                    <a class= "btn btn-success"
                                        href="<?php echo e(route('viewPelanty', ['id' => $employee->id, 'emp_name' => $employee->emp_name])); ?>"  style="width: 90px ;height: 62px;">عرض
                                        العقوبات</a>
                                </td>
                                <td>
                                    <a class= "btn btn-primary"
                                        href="<?php echo e(route('viewvac', ['id' => $employee->id, 'emp_name' => $employee->emp_name])); ?>"  style="width: 90px ;height: 62px;">عرض
                                        الاجازات</a>
                                </td>
                                <td>
                                    <a class= "btn btn-success"
                                        href="<?php echo e(route('viewAbsence', ['id' => $employee->id, 'emp_name' => $employee->emp_name])); ?>"  style="width: 90px ;height: 62px;">عرض
                                        الغيابات</a>
                                </td>
                                <td>
                                    <a class= "btn btn-danger"
                                        href="<?php echo e(route('gbonuscreate', ['emp_id' => $employee->id, 'emp_name' => $employee->emp_name])); ?>"  style="width: 90px ;height: 62px;">
                                        اصدار علاوة</a>
                                </td>
                                <td>
                                    <a class= "btn btn-primary"
                                        href="<?php echo e(route('viewgbonus', ['emp_id' => $employee->id, 'emp_name' => $employee->emp_name])); ?>"  style="width: 90px ;height: 62px;">
                                        عرض العلاوات </a>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>





                    </tbody>
              

                <tfoot>




                </tfoot>
            </table>
          
                
         



        </div>


        <div>
        </div>


    </section>
    <?php else: ?>
    <?php
        header('Location: ' . URL::to('/home'));
        exit();
    ?>

<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('define-degree.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\bonus\resources\views/alerts/bonus_alert.blade.php ENDPATH**/ ?>