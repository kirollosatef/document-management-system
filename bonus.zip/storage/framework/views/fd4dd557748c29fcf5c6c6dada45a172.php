
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark menu">
     
          <!-- Brand -->
          <!-- <a class="navbar-brand" href="#">نظام ادارة معلومات الموظفين</a> -->
      
          <!-- Toggle button for mobile view -->
          <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav"
                  aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
          </button>
      
          <!-- Navbar items and search box -->
          <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ms-auto">
              <li class="nav-item active">
                <a class="nav-link" href="<?php echo e(route('home')); ?>">الرئيسية</a>
              </li>
            <li class="nav-item dropdown">
                <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                  الملفات التعريفية
                </a>
                <ul class="dropdown-menu" style="text-align:center">
                  
                  <li><a class="dropdown-item" href="<?php echo e(route('department.index')); ?>"> تعريف مواقع العمل </a></li>
                  <li><a class="dropdown-item" href="<?php echo e(route('jobdes.index')); ?>">تعريف العناوين الوظيفية </a></li>
                  <li><a class="dropdown-item" href="<?php echo e(route('education.index')); ?>">تعريف التحصيل الدراسي </a></li>
                  <li><a class="dropdown-item" href="<?php echo e(route('vacation.index')); ?>">تعريف الاجازات </a></li>
                  <li><a class="dropdown-item" href="<?php echo e(route('alert.create')); ?>">فترة التنبيه</a></li>
                  
                </ul>
              </li>
              
              <li class="nav-item dropdown">
                <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                  الموظفين
                </a>
                <ul class="dropdown-menu" style="text-align:center">
                  <li><a class="dropdown-item" href="<?php echo e(route('employee.create')); ?>">فتح ملف موظف</a></li>
                  <li><a class="dropdown-item" href="<?php echo e(route('employee.index')); ?>">عرض الموظفين</a></li>
               
                </ul>
              </li>
              <li class="nav-item dropdown">
                <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                  التشكرات والعقوبات
                </a>
                <ul class="dropdown-menu" style="text-align:center">
                  <li><a class="dropdown-item" href="<?php echo e(route('thank.create')); ?>">التشكرات</a></li>
                  <li><a class="dropdown-item" href="<?php echo e(route('penalty.create')); ?>">العقوبات</a></li>
               
                </ul>
              </li>
              <li class="nav-item dropdown">
                <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                   الاجازات والغيابات
                </a>
                <ul class="dropdown-menu" style="text-align:center">
                  <li><a class="dropdown-item" href="<?php echo e(route('vac.create')); ?>">الاجازات</a></li>
                  <li><a class="dropdown-item" href="<?php echo e(route('absence.create')); ?>">الغيابات</a></li>
               
                </ul>
              </li>
           
              <li class="nav-item dropdown">
                <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                   التقارير
                </a>
                <ul class="dropdown-menu" style="text-align:center">
                  <li><a class="dropdown-item" href="<?php echo e(route('bonusreport')); ?>">تقرير العلاوات المستحقة</a></li>
                  <li><a class="dropdown-item" href="<?php echo e(route('proreport')); ?>">تقرير الترفيعات المستحقة</a></li>
                  <li><a class="dropdown-item" href="<?php echo e(route('retreport')); ?>">تقرير استحقاق التقاعد </a></li>
               
                </ul>
              </li>
           
              <li class="nav-item dropdown">
                <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                   التنبيهات
                </a>
                <ul class="dropdown-menu" style="text-align:center">
                  <li><a class="dropdown-item" href="<?php echo e(route('bonusalert')); ?>">تنبيهات العلاوات المستحقة</a></li>
                  <li><a class="dropdown-item" href="<?php echo e(route('proalert')); ?>">تنبيهات الترفيعات المستحقة</a></li>
                  <li><a class="dropdown-item" href="<?php echo e(route('retalert')); ?>">تنبيهات استحقاق التقاعد </a></li>
               
                </ul>
              </li>
              <li class="nav-item dropdown">
                <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                   المستخدمين
                </a>
                <ul class="dropdown-menu" style="text-align:center">
                  <li><a class="dropdown-item" href="<?php echo e(route('admin.create')); ?>">اضافة مستخدمين</a></li>
                  <li><a class="dropdown-item" href="<?php echo e(route('admin.index')); ?>">عرض المستخدمين</a></li>
              
                </ul>
              </li>
           
          
         
              
            
              <li class="nav-item">
                <form method="POST" action="<?php echo e(route('logout')); ?>">
                    <?php echo csrf_field(); ?>
                    <button type="submit" class="nav-link" style="border: none; background: none; cursor: pointer;">تسجيل خروج</button>
                </form>
            </li>
              
              <!-- Add more navbar items as needed -->
      
              <!-- Search box -->
              <!-- <li class="nav-item">
                <form class="d-flex" method="POST" action="search.php" >
                  <input  class="form-control me-2" type="search" placeholder="ابحث عن  ..." aria-label="Search"  name="keyword">
                  <button class="btn btn-success" type="submit">بحث</button>
                </form>
              </li> -->
            </ul>
          </div>
        </div>
      </nav<?php /**PATH C:\bonus\resources\views/menu.blade.php ENDPATH**/ ?>