
<?php $__env->startSection('content'); ?>
    <section>
        <?php if(session('admin_role')[5] == 1): ?>


        <div class="container mt-4  ">
            <?php if($errors->any()): ?>
                <div class="alert alert-danger">
                    <ul>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            <?php endif; ?>
            <div class="card shadow">
                <div class="card-header">
                    <h3>ملف الموظف</h3>
                </div>
                <div class="card-body">
                    <form class="row g-3" method="POST" id="insertform" action="<?php echo e(route('employee.store')); ?>">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('POST'); ?>
                        <div class="col-md-3">
                            <label for="inputPassword4" class="form-label"> رقم الموظف*</label>
                            <input type="number" class="form-control" name="emp_number" id="emp_number">
                        </div>
                        <div class="col-md-3">
                            <label for="inputPassword4" class="form-label"> الاسم الكامل *</label>
                            <input type="text" class="form-control" name="emp_name" id="emp_name">
                        </div>
                   
                        <div class="col-md-3" style="margin-top:20px ;">
                            <label for="selectData" class="mb-1"> العنوان الوظيفي*</label>
                            <select class="form-control select2 custom-select-height" name="jobdes" id="jobdes">
                               <?php $__currentLoopData = $jobdeses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jobdes): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                               <option value="<?php echo e($jobdes->jobdes); ?>"><?php echo e($jobdes->jobdes); ?></option>
                               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          
                            </select>
                        </div>
                        <div class="col-md-3" style="margin-top:20px ;">
                            <label for="selectData" class="mb-1">التحصيل الدراسي*</label>
                            <select class="form-control select2 custom-select-height" name="education" id="education">
                               <?php $__currentLoopData = $educations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $education): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                               <option value="<?php echo e($education->education); ?>"><?php echo e($education->education); ?></option>
                               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          
                            </select>
                        </div>
                        <div class="col-md-3" style="margin-top:20px ;">
                            <label for="selectData" class="mb-1"> موقع العمل*</label>
                            <select class="form-control select2 custom-select-height" name="department" id="department">
                               <?php $__currentLoopData = $departments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $department): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                               <option value="<?php echo e($department->dep_name); ?>"><?php echo e($department->dep_name); ?></option>
                               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          
                            </select>
                        </div>
                        <div class="col-md-3">
                            <label for="inputPassword4" class="form-label"> التولد*</label>
                            <input type="date" class="form-control" name="birth_day" id="birth_day" value="<?php echo e(date('Y-m-d')); ?>">
                        </div>
                        <div class="col-md-3" style="margin-top:20px ;">
                            <label for="selectData" class="mb-1">الدرجة*</label>
                            <select class="form-control  custom-select-height" name="degree" id="degree">
                                <option value="1">1</option>
                                <option value="2">2</option>
                                <option value="3">3</option>
                                <option value="4">4</option>
                                <option value="5">5</option>
                                <option value="6">6</option>
                                <option value="7">7</option>
                                <option value="8">8</option>
                                <option value="9">9</option>
                                <option value="10">10</option>
                            </select>
                        </div>
                        <div class="col-md-3" style="margin-top:20px ;">
                            <label for="selectData" class="mb-1">المرحلة*</label>
                            <select class="form-control  custom-select-height" name="stage" id="stage">
                                <option value="1">1</option>
                                <option value="2">2</option>
                                <option value="3">3</option>
                                <option value="4">4</option>
                                <option value="5">5</option>
                                <option value="6">6</option>
                                <option value="7">7</option>
                                <option value="8">8</option>
                                <option value="9">9</option>
                                <option value="10">10</option>
                                <option value="11">11</option>
                            </select>
                        </div>
                        <div class="col-md-3">
                            <label for="inputPassword4" class="form-label"> الراتب الحالي *</label>
                            <input type="number" class="form-control" name="salary" id="salary">
                        </div>
                     
                      
                        <div class="col-md-3">
                            <label for="inputPassword4" class="form-label">تاريخ المباشرة*</label>
                            <input type="date" class="form-control" name="start_date" id="start_date" value="<?php echo e(date('Y-m-d')); ?>">
                        </div>
                        <div class="col-md-3" style="margin-top:20px ;">
                            <label for="selectData" class="mb-1">نوع القيد*</label>
                            <select class="form-control select2 custom-select-height" name="emp_type" id="emp_type">
                                <option value="ملاك">ملاك</option>
                                <option value="عقد">عقد</option>
                                <option value="تقاعد">تقاعد</option>
                             
                            </select>
                        </div>
                        <div class="col-md-3">
                            <label for="inputPassword4" class="form-label"> تاريخ اخر علاوة*</label>
                            <input type="date" class="form-control" name="last_bonus" id="last_bonus"  value="<?php echo e(date('Y-m-d')); ?>">
                        </div>
                        <div class="col-md-3">
                            <label for="inputPassword4" class="form-label"> تاريخ اخر ترفيع*</label>
                            <input type="date" class="form-control" name="last_pro" id="last_pro" value="<?php echo e(date('Y-m-d')); ?>">
                        </div>
                        <div class="col-md-3">
                            <label for="inputPassword4" class="form-label"> الدرجة الجديدة*</label>
                            <input type="number" class="form-control" name="new_degree" id="new_degree">
                        </div>
                        <div class="col-md-3">
                            <label for="inputPassword4" class="form-label"> المرحلة الجديده*</label>
                            <input type="number" class="form-control" name="new_stage" id="new_stage">
                        </div>
                        <div class="col-md-3">
                            <label for="inputPassword4" class="form-label"> الراتب الجديد*</label>
                            <input type="number" class="form-control" name="new_salary" id="new_salary">
                        </div>
                        <div class="col-md-3">
                            <label for="inputPassword4" class="form-label"> تاريخ العلاوة القادم*</label>
                            <input type="date" class="form-control" name="new_bonus" id="new_bonus" >
                        </div>
                        <div class="col-md-3">
                            <label for="inputPassword4" class="form-label"> تاريخ  الترفيع القادم*</label>
                            <input type="date" class="form-control" name="new_pro" id="new_pro" >
                        </div>
                        <div class="col-md-3">
                            <label for="inputPassword4" class="form-label"> تاريخ التقاعد*</label>
                            <input type="date" class="form-control" name="retire_date" id="retire_date" >
                        </div>

                        <div class="col-12">
                            <button class="btn btn-primary" type="submit">
                                حفظ
                            </button>
                        </div>

                    </form>
                </div>
            </div>

        </div>
        <div class="container mt-5 ">

          <?php if($msg = Session::get('success')): ?>
          <div class="alert alert-success mt-2" role="alert">
              <?php echo e($msg); ?>

              <!-- Close button for the alert -->
              <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
          </div>
          <?php endif; ?>



      
               
    </section>
    <?php else: ?>
    <?php
        header('Location: ' . URL::to('/home'));
        exit();
    ?>

<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('define-degree.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\bonus\resources\views/employee/create.blade.php ENDPATH**/ ?>