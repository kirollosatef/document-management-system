
<?php $__env->startSection('content'); ?>
<?php if(session('admin_role')[6] == 1): ?>

    <section>



        <div class="container mt-4  ">
            <?php if($errors->any()): ?>
                <div class="alert alert-danger">
                    <ul>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            <?php endif; ?>
 
        </div>
        
         <div class="row me-1">
                     <div class="col-md-3 offset-md-3">
                         <form method="POST" action="<?php echo e(route('empsearch')); ?>">
                           <?php echo method_field('POST'); ?>
                           <?php echo csrf_field(); ?>
                             <div class="input-group">
                                 <input type="text" class="form-control" placeholder="ابحث" name="keyword">
                                 <button type="submit" class="btn btn-warning me-1  "
                                     name="search">البحث</button>
                             </div>
                         </form>
                     </div>
                 </div>
        <div class="container-fluid mt-3 ">

          <?php if($msg = Session::get('success')): ?>
          <div class="alert alert-success mt-2" role="alert">
              <?php echo e($msg); ?>

              <!-- Close button for the alert -->
              <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
          </div>
          <?php endif; ?>
          <table id="dtBasicExample" class="table table-striped table-bordered table-sm" cellspacing="0" width="100%">
            <thead class="table-dark">
              <tr>
                <th class="th-sm" >رقم الموظف</th>
                <th class="th-sm">اسم الموظف</th>
                <th class="th-sm">العنوان الوظيفي</th>
                <th class="th-sm">التحصيل الدراسي</th>
                <th class="th-sm">مكان العمل</th>
                <th class="th-sm">تاريخ الميلاد</th>
                <th class="th-sm">الدرجة</th>
                <th class="th-sm">المرحلة</th>
                <th class="th-sm">الراتب الحالي</th>
                <th class="th-sm">تاريخ المباشرة</th>
                <th class="th-sm">نوع القيد</th>
                <th class="th-sm">اخر علاوة</th>
                <th class="th-sm">اخر ترفيع</th>
                <th class="th-sm">الدرجة الجديدة</th>
                <th class="th-sm">المرحلة الجديدة</th>
                <th class="th-sm">الراتب الجديدة</th>
                <th class="th-sm">تاريخ العلاوة الجديدة</th>
                <th class="th-sm">تاريخ الترفيع الجديد</th>
                <th class="th-sm">تاريخ التقاعد</th>
                <th class="th-sm"></th>
                <th class="th-sm"></th>
                <th class="th-sm"></th>
                <th class="th-sm"></th>
                <th class="th-sm"></th>
                <th class="th-sm"></th>
                <th class="th-sm"></th>
                <th class="th-sm"></th>
                <th class="th-sm"></th>
               
              </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $employees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td>
                       <?php echo e($employee->emp_number); ?>

                    </td>
                    <td>
                       <?php echo e($employee->emp_name); ?>

                    </td>
                  
                    <td>
                       <?php echo e($employee->jobdes); ?>

                    </td>
                  
                    <td>
                       <?php echo e($employee->education); ?>

                    </td>
                  
                    <td>
                       <?php echo e($employee->department); ?>

                    </td>
                  
                    <td>
                       <?php echo e($employee->birth_day); ?>

                    </td>
                  
                    <td>
                       <?php echo e($employee->degree); ?>

                    </td>
                  
                    <td>
                       <?php echo e($employee->stage); ?>

                    </td>
                    <td>
                       <?php echo e($employee->salary); ?>

                    </td>
                    <td>
                       <?php echo e($employee->start_date); ?>

                    </td>
                    <td>
                       <?php echo e($employee->emp_type); ?>

                    </td>
                    <td>
                       <?php echo e($employee->last_bonus); ?>

                    </td>
                    <td>
                       <?php echo e($employee->last_pro); ?>

                    </td>
                  
                    <td>
                       <?php echo e($employee->new_degree); ?>

                    </td>
                  
                    <td>
                       <?php echo e($employee->new_stage); ?>

                    </td>
                  
                    <td>
                       <?php echo e($employee->new_salary); ?>

                    </td>
                  
                    <td>
                       <?php echo e($employee->new_bonus); ?>

                    </td>
                    <td>
                       <?php echo e($employee->new_pro); ?>

                    </td>
                    <td>
                       <?php echo e($employee->retire_date); ?>

                    </td>
                  
                  
                   
              
                    
                    <td>
                     <a  class= "btn btn-danger" href="<?php echo e(route('employee.edit',$employee->id)); ?>">تعديل معلومات</a>
                    </td>
                    <td>
                     <a  class= "btn btn-primary" href="<?php echo e(route('viewThanks',['id'=>$employee->id,'emp_name'=>$employee->emp_name])); ?>">عرض التشكرات</a>
                    </td>
                    <td>
                     <a  class= "btn btn-success" href="<?php echo e(route('viewPelanty',['id'=>$employee->id,'emp_name'=>$employee->emp_name])); ?>">عرض العقوبات</a>
                    </td>
                    <td>
                     <a  class= "btn btn-primary" href="<?php echo e(route('viewvac',['id'=>$employee->id,'emp_name'=>$employee->emp_name])); ?>">عرض الاجازات</a>
                    </td>
                    <td>
                     <a  class= "btn btn-success" href="<?php echo e(route('viewAbsence',['id'=>$employee->id,'emp_name'=>$employee->emp_name])); ?>">عرض الغيابات</a>
                    </td>
                    <td>
                     <a class= "btn btn-danger"
                         href="<?php echo e(route('gbonuscreate', ['emp_id' => $employee->id, 'emp_name' => $employee->emp_name])); ?>"  style="width: 90px ;height: 62px;">
                         اصدار علاوة</a>
                 </td>
                 <td>
                     <a class= "btn btn-primary"
                         href="<?php echo e(route('viewgbonus', ['emp_id' => $employee->id, 'emp_name' => $employee->emp_name])); ?>"  style="width: 90px ;height: 62px;">
                         عرض العلاوات </a>
                 </td>
                 <td>
                  <a class= "btn btn-danger"
                      href="<?php echo e(route('gprocreate', ['emp_id' => $employee->id, 'emp_name' => $employee->emp_name])); ?>"  style="width: 90px ;height: 62px;">
                      اصدار ترفيع</a>
              </td>
              <td>
                  <a class= "btn btn-primary"
                      href="<?php echo e(route('viewgpro', ['emp_id' => $employee->id, 'emp_name' => $employee->emp_name])); ?>"  style="width: 90px ;height: 62px;">
                      عرض الترفيعات </a>
              </td>
                </tr>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
               




            </tbody>
           
            <tfoot>
               
              
          
             
            </tfoot>
         </table>
         <?php echo e($employees->links('pagination::bootstrap-5')); ?>




              
                  
                
              </div>
              


              <div>
              </div>
              
               
    </section>
    <?php else: ?>
    <?php
        header('Location: ' . URL::to('/home'));
        exit();
    ?>

<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('define-degree.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\bonus\resources\views/employee/index.blade.php ENDPATH**/ ?>