
<?php $__env->startSection('content'); ?>
    sdfsdfsdfsdfsdf
<?php $__env->stopSection(); ?>
<?php echo $__env->make('define-degree.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\bonus\resources\views/define-degree/def-degree-index.blade.php ENDPATH**/ ?>