<!DOCTYPE html>
<html lang="en" dir="rtl"> 
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>نظام ادارة العلاوات والترفيعات</title>
    <link href="<?php echo e(asset('bootstrap.min.css')); ?>" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <script src="<?php echo e(asset('bootstrap.bundle.min.js')); ?>" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="<?php echo e(asset('font-awesome-4.7.0/css/font-awesome.min.css')); ?>">
    <script src="<?php echo e(asset('jquery-3.6.0.min.js')); ?>"></script>
    <link href="<?php echo e(asset('select22.min.css')); ?>" rel="stylesheet">
    <script src="<?php echo e(asset('select2.min.js')); ?>"></script> 
    <link rel="stylesheet" href="<?php echo e(asset('main2.css')); ?>">


    <link rel="stylesheet" href="<?php echo e(asset('main.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('main2.css')); ?>">
</head>
<body style="background-color: rgb(130, 159, 255)">
    
<?php echo $__env->make('menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->yieldContent('content'); ?>
</div>



<script>

	$.fn.jQuerySimpleCounter = function( options ) {
	    var settings = $.extend({
	        start:  0,
	        end:    100,
	        easing: 'swing',
	        duration: 400,
	        complete: ''
	    }, options );

	    var thisElement = $(this);

	    $({count: settings.start}).animate({count: settings.end}, {
			duration: settings.duration,
			easing: settings.easing,
			step: function() {
				var mathCount = Math.ceil(this.count);
				thisElement.text(mathCount);
			},
			complete: settings.complete
		});
	};
	var number1 = document.getElementById('number1').innerText;
	var number2 = document.getElementById('number2').innerText;
	var number3 = document.getElementById('number3').innerText;
	var number4 = document.getElementById('number4').innerText;
	var number5 = document.getElementById('number5').innerText;
	var number6 = document.getElementById('number6').innerText;
	var number7 = document.getElementById('number7').innerText;
	var number8 = document.getElementById('number8').innerText;

$('#number1').jQuerySimpleCounter({ end: parseInt(number1), duration: 3000 });
$('#number2').jQuerySimpleCounter({ end: parseInt(number2), duration: 3000 });
$('#number3').jQuerySimpleCounter({ end: parseInt(number3), duration: 3000 });
$('#number4').jQuerySimpleCounter({ end: parseInt(number4), duration: 3000 });
$('#number5').jQuerySimpleCounter({ end: parseInt(number5), duration: 3000 });
$('#number6').jQuerySimpleCounter({ end: parseInt(number6), duration: 3000 });
$('#number7').jQuerySimpleCounter({ end: parseInt(number7), duration: 3000 });
$('#number8').jQuerySimpleCounter({ end: parseInt(number8), duration: 3000 });



  	/* AUTHOR LINK */
     $('.about-me-img').hover(function(){
            $('.authorWindowWrapper').stop().fadeIn('fast').find('p').addClass('trans');
        }, function(){
            $('.authorWindowWrapper').stop().fadeOut('fast').find('p').removeClass('trans');
        });
</script>
<script src="<?php echo e(asset('main.js')); ?>">

</script>
                
</body>

</html><?php /**PATH C:\bonus\resources\views/home/home-layout.blade.php ENDPATH**/ ?>