
<?php $__env->startSection('content'); ?>
    <section >



        <div class="container mt-4  ">
            <?php if($errors->any()): ?>
                <div class="alert alert-danger">
                    <ul>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            <?php endif; ?>

     
            
              <div class="sectiontitle">
                <h2 class="text-light">احصائيات نظام ادارة العلاوات والترفيعات والتقاعد</h2>
                <span class="headerLine"></span>
            </div>
            <div id="projectFacts" class="sectionClass">
                <div class="fullWidth eight columns">
                    <div class="projectFactsWrap ">
                        <div class="item wow fadeInUpBig animated animated" data-number="1" style="visibility: visible;">
                            <i class="fa fa-users"></i>
                            <p id="number1" class="number"><?php echo e($emp); ?></p>
                            <span></span>
                            <p>موظفين</p>
                        </div>
                        <div class="item wow fadeInUpBig animated animated" data-number="55" style="visibility: visible;">
                            <i class="fa fa-file-text"></i>
                            <p id="number2" class="number"><?php echo e($thanks); ?></p>
                            <span></span>
                            <p>كتب شكر ممنوحه</p>
                        </div>
                        <div class="item wow fadeInUpBig animated animated" data-number="359" style="visibility: visible;">
                            <i class="fa fa-window-close-o"></i>
                            <p id="number3" class="number"><?php echo e($pals); ?></p>
                            <span></span>
                            <p>عقوبات ممنوحة</p>
                        </div>
                        <div class="item wow fadeInUpBig animated animated" data-number="246" style="visibility: visible;">
                            <i class="fa fa-calendar"></i>
                            <p id="number4" class="number"><?php echo e($vacs); ?></p>
                            <span></span>
                            <p>اجازات ممنوحه</p>
                        </div>
                    </div>
                </div>
            </div>
            <div id="projectFacts" class="sectionClass">
                <div class="fullWidth eight columns">
                    <div class="projectFactsWrap ">
                        <div class="item wow fadeInUpBig animated animated" data-number="12" style="visibility: visible;">
                            <i class="fa fa-building"></i>
                            <p id="number5" class="number"><?php echo e($deps); ?></p>
                            <span></span>
                            <p>مواقع العمل</p>
                        </div>
                        <div class="item wow fadeInUpBig animated animated" data-number="55" style="visibility: visible;">
                            <i class="fa fa-briefcase"></i>
                            <p id="number6" class="number"><?php echo e($jobs); ?></p>
                            <span></span>
                            <p>عناوين وظيفية</p>
                        </div>
                        <div class="item wow fadeInUpBig animated animated" data-number="359" style="visibility: visible;">
                            <i class="fa fa-graduation-cap"></i>
                            <p id="number7" class="number"><?php echo e($eds); ?></p>
                            <span></span>
                            <p>تحصيلات دراسية</p>
                        </div>
                        <div class="item wow fadeInUpBig animated animated" data-number="246" style="visibility: visible;">
                            <i class="fa fa-user"></i>
                            <p id="number8" class="number"><?php echo e($admins-1); ?></p>
                            <span></span>
                            <p>مستخدمين</p>
                        </div>
                    </div>
                </div>
            </div>
           
              
            
              
            
                
            
            
         









   
        <div class="container mt-5 ">

          <?php if($msg = Session::get('success')): ?>
          <div class="alert alert-success mt-2" role="alert">
              <?php echo e($msg); ?>

              <!-- Close button for the alert -->
              <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
          </div>
          <?php endif; ?>



      
               
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('home.home-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\bonus\resources\views/home/home.blade.php ENDPATH**/ ?>