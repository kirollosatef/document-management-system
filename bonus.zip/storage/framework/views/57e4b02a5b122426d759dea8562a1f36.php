
<?php $__env->startSection('content'); ?>
<?php if(session('admin_role')[10] == 1): ?>
    <section>



        <div class="container mt-4  ">
            <?php if($errors->any()): ?>
                <div class="alert alert-danger">
                    <ul>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            <?php endif; ?>
            <div class="card shadow">
                <div class="card-header">
                    <h3>الغيابات</h3>
                </div>
                <div class="card-body">
                    <form class="row g-3" method="POST" id="insertform" action="<?php echo e(route('absence.store')); ?>">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('POST'); ?>
                        <div class="col-md-4" style="margin-top:20px ;">
                            <label for="selectData" class="mb-1">اسم الموظف*</label>
                            <select class="form-control select2 custom-select-height" name="emp_id" id="emp_id">
                                <option selected disabled>اختر موظف</option>

                               <?php $__currentLoopData = $employees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                               <option value="<?php echo e($employee->id); ?>"><?php echo e($employee->emp_name); ?></option>
                               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          
                            </select>
                        </div>
                        <div class="col-md-4">
                            <label for="inputPassword4" class="form-label"> تاريخ الغياب*</label>
                            <input type="date" class="form-control" name="absence_date" id="absence_date" value="<?php echo e(date('Y-m-d')); ?>">
                        </div>
                 
                        <div class="col-md-4">
                            <label for="inputPassword4" class="form-label"> رقم الامر*</label>
                            <input type="text" class="form-control" name="absence_number" id="thanks_number">
                        </div>
                        <div class="col-md-4">
                            <label for="inputPassword4" class="form-label"> عدد ايام الغياب (يوم)*</label>
                            <input type="text" class="form-control" name="days_count" id="days_count" value="1">
                        </div>
                   
                
                      
                  
                        <div class="col-md-4">
                            <label for="inputPassword4" class="form-label">الملاحضات </label>
                            <input type="text" class="form-control" name="notes" id="notes">
                        </div>
                     
                      
                     
                    

                        <div class="col-12">
                            <button class="btn btn-primary" type="submit">
                                حفظ
                            </button>
                        </div>

                    </form>
                </div>
            </div>

        </div>
        <div class="container mt-5 ">

          <?php if($msg = Session::get('success')): ?>
          <div class="alert alert-success mt-2" role="alert">
              <?php echo e($msg); ?>

              <!-- Close button for the alert -->
              <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
          </div>
          <?php endif; ?>


               
    </section>
    <?php else: ?>
    <?php
        header('Location: ' . URL::to('/home'));
        exit();
    ?>

<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('define-degree.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\bonus\resources\views/abcence/create.blade.php ENDPATH**/ ?>