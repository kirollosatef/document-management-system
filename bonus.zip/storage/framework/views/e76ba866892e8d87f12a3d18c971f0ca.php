<!DOCTYPE html>
<html lang="en" dir="rtl"> 
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>نظام ادارة العلاوات والترفيعات والتقاعد</title>
    <link href="<?php echo e(asset('bootstrap.min.css')); ?>" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <script src="<?php echo e(asset('bootstrap.bundle.min.js')); ?>" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="<?php echo e(asset('font-awesome.min.css')); ?>">
    <script src="<?php echo e(asset('jquery-3.6.0.min.js')); ?>"></script>
    <link href="<?php echo e(asset('select22.min.css')); ?>" rel="stylesheet">
    <script src="<?php echo e(asset('select2.min.js')); ?>"></script> 
    <link rel="stylesheet" href="<?php echo e(asset('main2.css')); ?>">
</head>
<body style="background-color: rgb(124, 185, 255)" >
    
<?php echo $__env->make('menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->yieldContent('content'); ?>
</div>




<script src="<?php echo e(asset('main.js')); ?>">

</script>
                
</body>

</html><?php /**PATH C:\bonus\resources\views/define-degree/layout.blade.php ENDPATH**/ ?>