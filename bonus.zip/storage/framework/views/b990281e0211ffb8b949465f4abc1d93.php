
<?php $__env->startSection('content'); ?>
<?php if(session('admin_role')[17] == 1): ?>
    <section>



        <div class="container mt-4  ">
            <?php if($errors->any()): ?>
                <div class="alert alert-danger">
                    <ul>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            <?php endif; ?>
            <div class="card shadow">
                <div class="card-header bg-dark text-light text-center">
                    <h3>عرض المستخدمين</h3>
                </div>
         
            </div>

        </div>
        <div class="container mt-5 ">

          <?php if($msg = Session::get('success')): ?>
          <div class="alert alert-success mt-2" role="alert">
              <?php echo e($msg); ?>

              <!-- Close button for the alert -->
              <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
          </div>
          <?php endif; ?>



          <div class="row justify-content-center">
              <div class="table-responsive table-scroll" data-mdb-perfect-scrollbar="true" style="position: relative;">
                  <table class="table table-striped mb-0 table-bordered">
                      <thead class="table-dark">
                          <tr>
                         
                              <th scope="col">المستخدم</th>

                              <th scope="col"></th>
                              
                            
                             

                          </tr>
                      </thead>
                      <tbody>
                          <?php $__currentLoopData = $admins; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $admin): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <tr>
                            <?php if($admin->username!="admin"): ?>
                            <td>
                            
                                <?php echo e($admin->username); ?>

                             </td>
                           
                           
                              
                            
                            
                             
                        
                              <td>
                                  <form action="<?php echo e(route('admin.destroy',$admin->id)); ?>" method="post">
                                      <?php echo method_field('delete'); ?>
                                      <?php echo csrf_field(); ?>
                                     
                                      <input class="form-control btn btn-danger " type="submit" value="حذف" id="deleteform" onclick="return confirmDelete();">
                                      
                                  </form>
                              </td>
                              <?php endif; ?>
                          </tr>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                         




                      </tbody>
                      
                  </table>
                  
              
                  
                
              </div>
              


              <div>
              </div>
              
               
    </section>
        <?php else: ?>
    <?php
        header('Location: ' . URL::to('/home'));
        exit();
    ?>

<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('define-degree.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\bonus\resources\views/auth/view.blade.php ENDPATH**/ ?>