<?php

use App\Http\Controllers\AbsenceController;
use App\Http\Controllers\AdminController;
use App\Http\Controllers\AlertController;
use App\Http\Controllers\DefineDegreeController;
use App\Http\Controllers\DepartmentController;
use App\Http\Controllers\EducationController;
use App\Http\Controllers\EmployeeController;
use App\Http\Controllers\GbonusController;
use App\Http\Controllers\GproController;
use App\Http\Controllers\JobdesController;
use App\Http\Controllers\PenaltyController;
use App\Http\Controllers\ThankController;
use App\Http\Controllers\VacationController;
use App\Http\Controllers\VacController;
use App\Models\Absence;
use App\Models\Gpro;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\SalaryController;
use App\Http\Middleware\AuthenticateMiddleware;


/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

Route::get('/', [AdminController::class,'login'])->name('login');
Route::post('/login', [AdminController::class, 'authenticate'])->name('authenticate');



Route::middleware(AuthenticateMiddleware::class)->group(function () {
Route::resource('def-degree',DefineDegreeController::class);
Route::resource('department',DepartmentController::class);
Route::resource('jobdes',JobdesController::class);
Route::resource('education',EducationController::class);
Route::resource('vacation',VacationController::class);
Route::resource('employee',EmployeeController::class);
Route::resource('thank',ThankController::class);
Route::get('/get-salary', [SalaryController::class,'getSalary'])->name('get-salary');
Route::get ('/viewthanks/{id}/{emp_name}',[ThankController::class,'viewThanks'])->name('viewThanks');
Route::get ('/viewpelanty/{id}/{emp_name}',[PenaltyController::class,'viewPelanty'])->name('viewPelanty');
Route::get ('/viewabsence/{id}/{emp_name}',[AbsenceController::class,'viewAbsence'])->name('viewAbsence');
Route::get ('/viewvac/{id}/{emp_name}',[VacController::class,'viewvac'])->name('viewvac');
Route::delete('/deletethanks/{thank_id}/{emp_id}' ,[ThankController::class,'destroy'] )->name('deletethanks');
Route::delete('/deletepelanty/{pelanty_id}/{emp_id}' ,[PenaltyController::class,'destroy'] )->name('deletepelanty');
Route::delete('/deleteabsence/{absence_id}/{emp_id}' ,[AbsenceController::class,'destroy'] )->name('deleteabsence');
Route::delete('/deletevac/{vac_id}/{emp_id}' ,[VacController::class,'destroy'] )->name('deletevac');
Route::resource('penalty',PenaltyController::class);
Route::resource('absence',AbsenceController::class);
Route::resource('vac',VacController::class);
Route::any('emp-search',[EmployeeController::class,'empSearch'])->name('empsearch');
Route::any('bonus-report',[EmployeeController::class,'bonusReport'])->name('bonusreport');
Route::any('bonus-report-print',[EmployeeController::class,'bonusReportPrint'])->name('bonusreportprint');
Route::any('pro-report',[EmployeeController::class,'proReport'])->name('proreport');
Route::any('pro-report-print',[EmployeeController::class,'proReportPrint'])->name('proreportprint');
Route::any('retire-report',[EmployeeController::class,'retReport'])->name('retreport');
Route::any('retire-report-print',[EmployeeController::class,'retReportPrint'])->name('retreportprint');
Route::any('bonus-alert',[EmployeeController::class,'bonusAlert'])->name('bonusalert');
Route::any('pro-alert',[EmployeeController::class,'proAlert'])->name('proalert');
Route::any('pro-ret',[EmployeeController::class,'retAlert'])->name('retalert');
Route::get('/home',[EmployeeController::class,'home'])->name('home');
Route::resource('alert',AlertController::class);
Route::get('gbonus-greate/{emp_id}/{emp_name}',[GbonusController::class,'gbonusCreate'] )->name('gbonuscreate');
Route::get('gpro-greate/{emp_id}/{emp_name}',[GproController::class,'gproCreate'] )->name('gprocreate');
Route::resource('gbonus',GbonusController::class);
Route::resource('gpro',GproController::class);
Route::get ('/viewgbonus/{emp_id}/{emp_name}',[GbonusController::class,'viewGbonus'])->name('viewgbonus');
Route::get ('/viewgpro/{emp_id}/{emp_name}',[GproController::class,'viewGpro'])->name('viewgpro');
Route::resource('admin',AdminController::class);
Route::post('/logout', [AdminController::class, 'logout'])->name('logout');
});





